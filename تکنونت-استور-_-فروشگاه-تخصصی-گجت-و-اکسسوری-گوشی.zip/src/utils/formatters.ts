// Helper utilities for Persian currency and digits

export function formatPrice(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

export function toPersianDigits(n: number | string): string {
  const farsiDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return n.toString().replace(/\d/g, x => farsiDigits[parseInt(x)]);
}

export function formatPersianPrice(num: number): string {
  const formatted = formatPrice(num);
  return toPersianDigits(formatted);
}
