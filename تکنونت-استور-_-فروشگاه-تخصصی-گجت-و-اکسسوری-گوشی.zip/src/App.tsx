import React from 'react';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomeView } from './components/HomeView';
import { StoreView } from './components/StoreView';
import { ProductDetailView } from './components/ProductDetailView';
import { CartView } from './components/CartView';
import { CategoriesView } from './components/CategoriesView';
import { FavoritesView } from './components/FavoritesView';
import { SupportView } from './components/SupportView';
import { SearchModal } from './components/SearchModal';
import { QuickBuyModal } from './components/QuickBuyModal';
import { Toast } from './components/Toast';

const AppContent: React.FC = () => {
  const { activePage } = useStore();

  return (
    <div className="min-h-screen flex flex-col bg-[#faf8fe] dark:bg-[#121316] text-[#1a1b1f] dark:text-[#f1f0f5] transition-colors duration-200">
      <Header />

      <main className="flex-1 w-full pt-20">
        {activePage === 'home' && <HomeView />}
        {activePage === 'store' && <StoreView />}
        {activePage === 'product-detail' && <ProductDetailView />}
        {activePage === 'cart' && <CartView />}
        {activePage === 'categories' && <CategoriesView />}
        {activePage === 'favorites' && <FavoritesView />}
        {activePage === 'support' && <SupportView />}
      </main>

      <Footer />

      {/* Global Modals & Overlays */}
      <SearchModal />
      <QuickBuyModal />
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <StoreProvider>
      <AppContent />
    </StoreProvider>
  );
}
