import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { CATEGORIES_META, PRODUCTS } from '../data/products';
import { formatPersianPrice } from '../utils/formatters';

export const HomeView: React.FC = () => {
  const { setActivePage, openProductDetail, addToCart, setCategoryFilter, toggleFavorite, isFavorite } = useStore();
  const [activeTab, setActiveTab] = useState<'all' | 'chargers' | 'cases' | 'audio'>('all');

  // Filter featured products by tab
  const featuredProducts = PRODUCTS.filter(p => {
    if (activeTab === 'all') return true;
    if (activeTab === 'chargers') return p.category === 'chargers' || p.category === 'cables' || p.category === 'powerbanks';
    if (activeTab === 'cases') return p.category === 'cases' || p.category === 'screen-protector';
    if (activeTab === 'audio') return p.category === 'audio';
    return true;
  }).slice(0, 4);

  return (
    <div className="flex flex-col w-full">
      {/* Hero Section */}
      <section className="relative w-full overflow-hidden bg-white dark:bg-[#16171b] pt-12 pb-16 lg:pb-24 border-b border-black/[0.03] dark:border-white/[0.04]">
        {/* Ambient Glows */}
        <div className="absolute inset-0 pointer-events-none opacity-40 dark:opacity-20">
          <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-[#0071e3]/15 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-20 left-10 w-[500px] h-[500px] bg-[#2f6af2]/10 rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10 max-w-[1380px] mx-auto px-4 sm:px-6 flex flex-col lg:flex-row items-center justify-between gap-12 lg:gap-8 min-h-[640px]">
          {/* Hero Text */}
          <div className="w-full lg:w-7/12 flex flex-col items-start text-right space-y-6">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#f0eff5] dark:bg-[#202126] text-gray-900 dark:text-gray-100 shadow-xs">
              <span className="w-2.5 h-2.5 rounded-full bg-[#0071e3] animate-pulse"></span>
              <span className="text-xs font-bold tracking-wide">کالکشن جدید پاییزه تکنونت ۲۰۲۵</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-gray-900 dark:text-white tracking-tight leading-[1.25]">
              تکنولوژی را{' '}
              <span className="bg-gradient-to-l from-[#005cbb] via-[#0071e3] to-[#2f6af2] bg-clip-text text-transparent">
                بهتر تجربه کن
              </span>
            </h1>

            <p className="text-base sm:text-lg text-gray-600 dark:text-gray-300 max-w-2xl leading-relaxed">
              مجموعه‌ای دست‌چین از لوکس‌ترین و پیشرفته‌ترین اکسسوری‌های گوشی و لوازم جانبی هوشمند با تلفیق آلیاژ تیتانیوم گرید هوافضا و مهندسی دقیق مینیمال.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => setActivePage('store')}
                className="px-6 py-3 rounded-full bg-[#0071e3] text-white font-semibold text-sm shadow-md hover:bg-[#005cbb] transition-all flex items-center gap-2 group cursor-pointer"
              >
                <span>مشاهده محصولات جدید</span>
                <span className="material-symbols-outlined text-lg group-hover:-translate-x-1 transition-transform">
                  arrow_left_alt
                </span>
              </button>

              <button
                onClick={() => openProductDetail('prod-magpro-titanium')}
                className="px-6 py-3 rounded-full bg-[#f0eff5] dark:bg-[#22242a] text-gray-800 dark:text-gray-200 hover:bg-[#e4e2e8] dark:hover:bg-[#2a2c34] font-semibold text-sm transition-all cursor-pointer"
              >
                کاوش کالکشن تیتانیوم
              </button>
            </div>

            {/* Micro Trust Pills */}
            <div className="grid grid-cols-2 gap-4 pt-4 w-full max-w-md">
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-[#f8f7fc] dark:bg-[#1e2025] shadow-xs border border-black/[0.02] dark:border-white/[0.04]">
                <span className="material-symbols-outlined text-[#0071e3] text-2xl font-semibold">verified_user</span>
                <span className="text-xs font-bold text-gray-900 dark:text-gray-100">گارانتی تعویض ۲۴ ماهه</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-2xl bg-[#f8f7fc] dark:bg-[#1e2025] shadow-xs border border-black/[0.02] dark:border-white/[0.04]">
                <span className="material-symbols-outlined text-[#0071e3] text-2xl font-semibold">local_shipping</span>
                <span className="text-xs font-bold text-gray-900 dark:text-gray-100">ارسال رایگان سراسر کشور</span>
              </div>
            </div>
          </div>

          {/* Hero Showcase Image Visual */}
          <div className="w-full lg:w-5/12 relative flex items-center justify-center">
            <div className="relative w-full max-w-md aspect-square rounded-3xl overflow-hidden shadow-2xl bg-[#eeedf3] dark:bg-[#1e2025] border border-black/[0.05] dark:border-white/[0.08] group">
              <img
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuCDnfjXo02RrU7xSRbAxnAbo1pfWZpDb5X58KidFpMEGPXnqsLlqurMiWL_5bRd2BGyFw1CmyfMSX_GbhYcGNxaeY69HkTcWBt90YvcLmzELcvwPwe52L_3Q9v07dzUhrEBnz_7j07R5Imlkj8WWAA6K_OzvDsASfQedxxXarGAy8mur0GfP-l-dPf_KwORBpLkH7kk8LlavWAUB-GZnRuGKVEdleHtf-RDrEUAudRNTSoKtUsLke4J"
                alt="پاوربانک و شارژر مگنتی هایپرگرید تیتانیوم"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              
              {/* Floating Bottom Card Banner */}
              <div
                onClick={() => openProductDetail('prod-magpro-titanium')}
                className="absolute bottom-4 right-4 left-4 p-4 rounded-2xl bg-white/95 dark:bg-[#1a1b1f]/95 backdrop-blur-xl shadow-lg border border-black/[0.05] dark:border-white/[0.1] flex items-center justify-between cursor-pointer hover:bg-white dark:hover:bg-[#202126] transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-[#0071e3]/15 dark:bg-[#0071e3]/25 flex items-center justify-center text-[#0071e3] dark:text-[#abc7ff]">
                    <span className="material-symbols-outlined text-xl">bolt</span>
                  </div>
                  <div>
                    <p className="text-xs font-bold text-gray-900 dark:text-white">شارژر مگنتی هایپرگرید</p>
                    <p className="text-[11px] text-gray-500 dark:text-gray-400">فوق‌سریع ۲۵ وات با خنک‌کننده فعال</p>
                  </div>
                </div>
                <span className="text-xs font-extrabold text-[#0071e3] dark:text-[#abc7ff]">
                  ۲,۹۵۰,۰۰۰ تومان
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 10 Categories Shelf */}
      <section className="w-full py-16 bg-[#faf8fe] dark:bg-[#121316]">
        <div className="max-w-[1380px] mx-auto px-4 sm:px-6">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
            <div>
              <span className="text-xs font-bold text-[#0071e3] dark:text-[#abc7ff] uppercase tracking-wider block">
                دسته‌بندی‌های اختصاصی
              </span>
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mt-1">
                تجهیزات متناسب با سبک زندگی دیجیتال
              </h2>
            </div>
            <button
              onClick={() => setActivePage('categories')}
              className="text-xs font-bold text-[#0071e3] dark:text-[#abc7ff] hover:underline flex items-center gap-1 self-start sm:self-auto"
            >
              <span>همه دسته‌بندی‌ها</span>
              <span className="material-symbols-outlined text-base">chevron_left</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
            {CATEGORIES_META.map(cat => (
              <button
                key={cat.id}
                onClick={() => setCategoryFilter(cat.id)}
                className="group p-4 rounded-2xl bg-white dark:bg-[#1a1b1f] hover:bg-[#f4f3f8] dark:hover:bg-[#22242a] shadow-xs hover:shadow-md transition-all duration-300 flex flex-col items-center text-center border border-black/[0.02] dark:border-white/[0.04]"
              >
                <div className="w-14 h-14 rounded-2xl bg-[#eeedf3] dark:bg-[#25262c] flex items-center justify-center text-gray-800 dark:text-gray-200 mb-3 group-hover:scale-110 group-hover:text-[#0071e3] transition-all">
                  <span className="material-symbols-outlined text-2xl">{cat.icon}</span>
                </div>
                <span className="font-bold text-sm text-gray-900 dark:text-white group-hover:text-[#0071e3] transition-colors">
                  {cat.name}
                </span>
                <span className="text-[11px] text-gray-500 dark:text-gray-400 mt-1 line-clamp-1">
                  {cat.subtitle}
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products Showcase with Category Tabs */}
      <section className="w-full py-16 bg-[#f4f3f8] dark:bg-[#16171b]">
        <div className="max-w-[1380px] mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
            <div>
              <div className="inline-flex items-center gap-1.5 text-[#0071e3] dark:text-[#abc7ff] text-xs font-bold mb-1">
                <span className="material-symbols-outlined text-base">hotel_class</span>
                <span>انتخاب کارشناسان تکنونت</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
                محصولات برگزیده و پیشگام بازار
              </h2>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === 'all'
                    ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900 shadow-sm'
                    : 'bg-white dark:bg-[#202126] text-gray-600 dark:text-gray-300 hover:bg-gray-100'
                }`}
              >
                همه محصولات
              </button>
              <button
                onClick={() => setActiveTab('chargers')}
                className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === 'chargers'
                    ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900 shadow-sm'
                    : 'bg-white dark:bg-[#202126] text-gray-600 dark:text-gray-300 hover:bg-gray-100'
                }`}
              >
                شارژر و کابل
              </button>
              <button
                onClick={() => setActiveTab('cases')}
                className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === 'cases'
                    ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900 shadow-sm'
                    : 'bg-white dark:bg-[#202126] text-gray-600 dark:text-gray-300 hover:bg-gray-100'
                }`}
              >
                کاور محافظ
              </button>
              <button
                onClick={() => setActiveTab('audio')}
                className={`px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
                  activeTab === 'audio'
                    ? 'bg-gray-900 dark:bg-white text-white dark:text-gray-900 shadow-sm'
                    : 'bg-white dark:bg-[#202126] text-gray-600 dark:text-gray-300 hover:bg-gray-100'
                }`}
              >
                صوتی
              </button>
            </div>
          </div>

          {/* 4 Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map(product => {
              const favorite = isFavorite(product.id);
              return (
                <div
                  key={product.id}
                  className="group bg-white dark:bg-[#1a1b1f] rounded-3xl p-4 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative border border-black/[0.03] dark:border-white/[0.04]"
                >
                  {/* Badge */}
                  {product.badge && (
                    <div className="absolute top-4 right-4 z-10 bg-[#0071e3] text-white text-[11px] px-2.5 py-1 rounded-full font-bold shadow-sm">
                      {product.badge}
                    </div>
                  )}

                  {/* Favorite button */}
                  <button
                    onClick={e => {
                      e.stopPropagation();
                      toggleFavorite(product.id);
                    }}
                    aria-label="افزودن به علاقه‌مندی"
                    className="absolute top-4 left-4 z-10 w-9 h-9 rounded-full bg-white/80 dark:bg-black/50 backdrop-blur-md flex items-center justify-center text-gray-600 dark:text-gray-300 hover:text-rose-600 transition-colors shadow-xs"
                  >
                    <span className={`material-symbols-outlined text-lg ${favorite ? 'filled text-rose-500' : ''}`}>
                      favorite
                    </span>
                  </button>

                  {/* Image stage */}
                  <div
                    onClick={() => openProductDetail(product.id)}
                    className="w-full aspect-square rounded-2xl bg-[#faf8fe] dark:bg-[#22242a] mb-4 overflow-hidden relative flex items-center justify-center p-4 cursor-pointer"
                  >
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>

                  {/* Info */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-400 font-semibold">{product.brand}</span>
                      <div className="flex items-center text-amber-500 font-bold gap-1">
                        <span className="material-symbols-outlined text-sm filled">star</span>
                        <span>{product.rating}</span>
                      </div>
                    </div>

                    <h3
                      onClick={() => openProductDetail(product.id)}
                      className="font-bold text-sm text-gray-900 dark:text-white group-hover:text-[#0071e3] transition-colors cursor-pointer line-clamp-1"
                    >
                      {product.name}
                    </h3>

                    <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1">
                      {product.shortSpecs}
                    </p>

                    {/* Colors */}
                    <div className="flex items-center gap-1.5 pt-1">
                      {product.colors.map((col, idx) => (
                        <span
                          key={col.id}
                          className={`w-3.5 h-3.5 rounded-full ${idx === 0 ? 'ring-1 ring-[#0071e3] ring-offset-1' : ''}`}
                          style={{ backgroundColor: col.hex }}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Price & CTA */}
                  <div className="pt-4 mt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
                    <div className="flex flex-col">
                      {product.originalPrice && (
                        <span className="text-[11px] text-gray-400 line-through">
                          {formatPersianPrice(product.originalPrice)}
                        </span>
                      )}
                      <span className="text-sm font-bold text-gray-900 dark:text-white">
                        {formatPersianPrice(product.price)}{' '}
                        <span className="text-[11px] font-normal text-gray-500">تومان</span>
                      </span>
                    </div>

                    <button
                      onClick={() => addToCart(product)}
                      className="w-10 h-10 rounded-full bg-[#0071e3] text-white flex items-center justify-center hover:bg-[#005cbb] active:scale-95 transition-all shadow-sm"
                      title="افزودن به سبد خرید"
                    >
                      <span className="material-symbols-outlined text-xl">add_shopping_cart</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* MagSafe Ecosystem Spotlight Section (Dark Architectural Mood) */}
      <section className="w-full py-20 bg-[#16171b] text-white relative overflow-hidden">
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-[#0071e3]/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-[1380px] mx-auto px-4 sm:px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left text */}
            <div className="lg:col-span-6 space-y-6 text-right">
              <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-white/10 backdrop-blur-md text-[#abc7ff]">
                <span className="material-symbols-outlined text-base">leak_add</span>
                <span className="text-xs font-bold tracking-wide">اکوسیستم اتصال مغناطیسی</span>
              </div>

              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white leading-tight">
                جادوی اتصال بی‌نقص با تکنولوژی مگ‌سیف
              </h2>

              <p className="text-sm sm:text-base text-gray-300 leading-relaxed">
                مجموعه ایستگاه‌های شارژ رومیزی، پایه‌های نگهدارنده داخل خودرو و والت‌های چرمی دست‌دوز، مهندسی شده برای هماهنگی میلی‌متری و شارژ بهینه بدون حرارت اضافی.
              </p>

              <div className="grid grid-cols-2 gap-4 pt-2">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
                  <span className="text-xl sm:text-2xl font-bold text-[#abc7ff] block">۱۵ وات واقعی</span>
                  <span className="text-xs text-gray-400 mt-1 block">تأییدیه رسمی Qi2 و اپل MFi</span>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-sm">
                  <span className="text-xl sm:text-2xl font-bold text-[#abc7ff] block">آهنربای N52</span>
                  <span className="text-xs text-gray-400 mt-1 block">قدرت جذب تا وزن ۱.۴ کیلوگرم</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  onClick={() => {
                    setCategoryFilter('chargers');
                  }}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-[#0071e3] text-white text-sm font-semibold hover:bg-[#005cbb] transition-all shadow-md cursor-pointer"
                >
                  <span>کاوش تمام ابزارهای مگ‌سیف</span>
                  <span className="material-symbols-outlined text-lg">arrow_left_alt</span>
                </button>
              </div>
            </div>

            {/* Right visual */}
            <div className="lg:col-span-6">
              <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl bg-white/5 border border-white/10 group">
                <img
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuBPdrLEUlvRDhaY006se91306S5UQ8xmlj7pQhfD20RBrTj7fVt-nvsWg2nRupByYhMuANjkI2bjx8-DonjUCmsyLYUCIEe1e3QzCPq05zfzj19zo6o8cdU-s1NUYnMXsSQwxPCrS3Maq3N39xlRZmph-FJGnnaCen8eFIJ189eQMN9lxkl1K9W5HH2GaH9rqGVwFhyMdDbXUvzmnw-m27anEttpvULtah5x8GYXSI7DrmsHnSigoaf"
                  alt="استند شارژ ۳ کاره مگ‌سیف"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4 Value Propositions */}
      <section className="w-full py-16 bg-white dark:bg-[#121316]">
        <div className="max-w-[1380px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
            <div className="flex flex-col items-center text-center p-6 rounded-3xl bg-[#f8f7fc] dark:bg-[#1a1b1f] border border-black/[0.02] dark:border-white/[0.04]">
              <div className="w-14 h-14 rounded-2xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-3xl font-bold">verified</span>
              </div>
              <h4 className="font-bold text-base text-gray-900 dark:text-white mb-1">اصالت تضمین‌شده</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                تمامی اقلام با هولوگرام رهگیری مستقیم از کارخانه تحویل داده می‌شوند.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-3xl bg-[#f8f7fc] dark:bg-[#1a1b1f] border border-black/[0.02] dark:border-white/[0.04]">
              <div className="w-14 h-14 rounded-2xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-3xl font-bold">rocket_launch</span>
              </div>
              <h4 className="font-bold text-base text-gray-900 dark:text-white mb-1">ارسال در همان روز</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                پردازش سریع و ارسال اکسپرس تهران با بسته‌بندی مقاوم ضدضربه صنعتی.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-3xl bg-[#f8f7fc] dark:bg-[#1a1b1f] border border-black/[0.02] dark:border-white/[0.04]">
              <div className="w-14 h-14 rounded-2xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-3xl font-bold">headset_mic</span>
              </div>
              <h4 className="font-bold text-base text-gray-900 dark:text-white mb-1">مشاوره فنی ۲۴/۷</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                پاسخگویی به نیازهای تخصصی سخت‌افزاری توسط مهندسان الکترونیک تکنونت.
              </p>
            </div>

            <div className="flex flex-col items-center text-center p-6 rounded-3xl bg-[#f8f7fc] dark:bg-[#1a1b1f] border border-black/[0.02] dark:border-white/[0.04]">
              <div className="w-14 h-14 rounded-2xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-3xl font-bold">published_with_changes</span>
              </div>
              <h4 className="font-bold text-base text-gray-900 dark:text-white mb-1">تعویض بی‌قید و شرط</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                ۷ روز مهلت تست فنی و بازگشت کامل وجه بدون کسر هزینه یا پیچیدگی اداری.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
