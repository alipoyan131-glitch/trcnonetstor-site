import React from 'react';
import { useStore } from '../context/StoreContext';

export const Toast: React.FC = () => {
  const { toastMessage } = useStore();

  if (!toastMessage) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-5 duration-300 pointer-events-none">
      <div className="bg-[#1a1b1f]/95 dark:bg-white/95 text-white dark:text-[#1a1b1f] px-5 py-3 rounded-full shadow-2xl backdrop-blur-md flex items-center gap-3 border border-white/10 dark:border-black/10">
        <span className="material-symbols-outlined text-[#abc7ff] dark:text-[#0071e3] text-xl font-bold">
          check_circle
        </span>
        <span className="text-sm font-medium">{toastMessage}</span>
      </div>
    </div>
  );
};
