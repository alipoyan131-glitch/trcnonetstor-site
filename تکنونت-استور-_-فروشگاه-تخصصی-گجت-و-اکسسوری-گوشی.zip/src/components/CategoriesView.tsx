import React from 'react';
import { useStore } from '../context/StoreContext';
import { CATEGORIES_META, PRODUCTS } from '../data/products';
import { toPersianDigits } from '../utils/formatters';

export const CategoriesView: React.FC = () => {
  const { setCategoryFilter } = useStore();

  return (
    <div className="w-full pb-20 pt-6">
      <div className="max-w-[1380px] mx-auto px-4 sm:px-6">
        {/* Banner */}
        <div className="text-right mb-10 space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] text-xs font-bold">
            <span className="material-symbols-outlined text-sm">category</span>
            <span>اطلس دسته‌بندی‌های تخصصی تکنونت</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 dark:text-white">
            دسته‌بندی‌های لوازم و گجت‌های هوشمند
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 max-w-xl">
            تمام تجهیزات بر اساس استانداردهای مهندسی، نوع پروتکل اتصال و نیازهای سبک زندگی دیجیتال طبقه‌بندی شده‌اند.
          </p>
        </div>

        {/* 10 Grid Categories */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {CATEGORIES_META.map(cat => {
            const countInCatalog = PRODUCTS.filter(p => p.category === cat.id).length;
            return (
              <div
                key={cat.id}
                onClick={() => setCategoryFilter(cat.id)}
                className="group bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 shadow-xs hover:shadow-xl transition-all duration-300 border border-black/[0.03] dark:border-white/[0.05] cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-14 h-14 rounded-2xl bg-[#eeedf3] dark:bg-[#25262c] text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center group-hover:scale-110 group-hover:bg-[#0071e3] group-hover:text-white transition-all shadow-xs">
                      <span className="material-symbols-outlined text-3xl font-bold">{cat.icon}</span>
                    </div>
                    <span className="text-xs font-bold text-gray-400 bg-[#f4f3f8] dark:bg-[#202126] px-3 py-1 rounded-full">
                      {toPersianDigits(cat.count)} کالا در کاتالوگ
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-gray-900 dark:text-white group-hover:text-[#0071e3] transition-colors mb-1 text-right">
                    {cat.name}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 text-right leading-relaxed">
                    {cat.subtitle}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between text-xs text-[#0071e3] dark:text-[#abc7ff] font-bold">
                  <span>مشاهده محصولات این دسته</span>
                  <span className="material-symbols-outlined text-base group-hover:-translate-x-1 transition-transform">
                    arrow_left_alt
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
