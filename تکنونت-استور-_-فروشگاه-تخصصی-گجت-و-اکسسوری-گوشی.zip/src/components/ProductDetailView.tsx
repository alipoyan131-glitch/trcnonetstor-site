import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { PRODUCTS } from '../data/products';
import { formatPersianPrice, toPersianDigits } from '../utils/formatters';

export const ProductDetailView: React.FC = () => {
  const {
    selectedProductId,
    openProductDetail,
    addToCart,
    toggleFavorite,
    isFavorite,
    setActivePage,
    setIsQuickBuyOpen,
    setQuickBuyProduct,
    showToast,
  } = useStore();

  const product = PRODUCTS.find(p => p.id === selectedProductId) || PRODUCTS[0];

  // Local state
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [selectedCapacity, setSelectedCapacity] = useState(product.capacities ? product.capacities[0] : undefined);
  const [activeThumbIndex, setActiveThumbIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [activeTab, setActiveTab] = useState<'engineering' | 'specs' | 'reviews'>('engineering');
  const [simulatedTemp, setSimulatedTemp] = useState(31.2);
  const [addedBtnState, setAddedBtnState] = useState(false);

  // Review submission
  const [newReviewAuthor, setNewReviewAuthor] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewComment, setNewReviewComment] = useState('');
  const [customReviews, setCustomReviews] = useState(product.reviews || []);

  const favorite = isFavorite(product.id);

  // Gallery items (fallback to product image if no gallery)
  const galleryItems = product.gallery && product.gallery.length > 0
    ? product.gallery
    : [
        { thumbnail: product.image, caption: 'نمای اصلی کالا', largeAlt: product.name },
        { thumbnail: product.hoverImage, caption: 'نمای زاویه‌دار', largeAlt: product.name },
      ];

  const currentDisplayImage = galleryItems[activeThumbIndex]?.thumbnail || product.image;

  // Price computation with selected capacity delta
  const priceDelta = selectedCapacity?.priceDelta || 0;
  const currentPrice = product.price + priceDelta;
  const currentOriginalPrice = product.originalPrice ? product.originalPrice + priceDelta : undefined;

  const handleAddToCart = () => {
    addToCart(product, selectedColor, selectedCapacity, 1);
    setAddedBtnState(true);
    setTimeout(() => setAddedBtnState(false), 2400);
  };

  const handleInstantBuy = () => {
    setQuickBuyProduct(product);
    setIsQuickBuyOpen(true);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewAuthor.trim() || !newReviewComment.trim()) return;

    const newRev = {
      id: `rev-${Date.now()}`,
      author: newReviewAuthor,
      initials: newReviewAuthor.slice(0, 2),
      avatarColor: 'bg-[#0071e3]/15 text-[#0071e3]',
      rating: newReviewRating,
      date: 'لحظاتی پیش',
      variantPurchased: selectedColor.name,
      comment: newReviewComment,
      verified: true,
    };

    setCustomReviews(prev => [newRev, ...prev]);
    setNewReviewAuthor('');
    setNewReviewComment('');
    showToast('دیدگاه شما با موفقیت ثبت شد و پس از بررسی منتشر خواهد شد.');
  };

  // Complementary ecosystem products (excluding current)
  const complementaryProducts = PRODUCTS.filter(
    p => p.id === 'prod-magcord-100w' || p.id === 'prod-magcharge-65w' || p.id === 'prod-magarmor-case'
  );

  return (
    <div className="w-full pb-20">
      {/* Top Breadcrumb & Quick Actions Bar */}
      <section className="max-w-[1380px] w-full mx-auto px-4 sm:px-6 py-3">
        <div className="flex flex-wrap items-center justify-between gap-3 bg-white/70 dark:bg-[#1a1b1f]/70 backdrop-blur-md rounded-full px-5 py-2.5 shadow-xs border border-black/[0.03] dark:border-white/[0.04]">
          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 overflow-x-auto whitespace-nowrap">
            <button onClick={() => setActivePage('home')} className="hover:text-[#0071e3] transition-colors flex items-center gap-1">
              <span className="material-symbols-outlined text-base">home</span>
              <span>خانه</span>
            </button>
            <span className="material-symbols-outlined text-xs text-gray-300">chevron_left</span>
            <button onClick={() => setActivePage('store')} className="hover:text-[#0071e3] transition-colors">
              {product.categoryLabel}
            </button>
            <span className="material-symbols-outlined text-xs text-gray-300">chevron_left</span>
            <span className="text-gray-900 dark:text-white font-semibold">{product.name}</span>
          </div>

          <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
            <span className="inline-flex items-center gap-1 bg-[#0071e3]/10 dark:bg-[#0071e3]/20 px-2.5 py-0.5 rounded-full text-[#0071e3] dark:text-[#abc7ff] font-medium">
              <span className="w-1.5 h-1.5 rounded-full bg-[#0071e3] animate-pulse"></span>
              عرضه رسمی ۲۰۲۵
            </span>
            <span className="hidden sm:inline text-gray-300">•</span>
            <span className="hidden sm:inline font-mono">شناسه: {product.code}</span>
          </div>
        </div>
      </section>

      {/* Main Studio Presentation Layout */}
      <section className="max-w-[1380px] w-full mx-auto px-4 sm:px-6 py-6 lg:py-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Right Column (RTL Primary View): Studio Interactive Gallery */}
          <div className="lg:col-span-7 flex flex-col gap-6">
            {/* Main Stage Container */}
            <div className="relative bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-10 shadow-sm border border-black/[0.04] dark:border-white/[0.06] overflow-hidden group">
              {/* Ambient Glows */}
              <div className="absolute -top-24 -right-24 w-80 h-80 bg-[#0071e3]/10 rounded-full blur-3xl pointer-events-none transition-all duration-700 group-hover:scale-125"></div>
              <div className="absolute -bottom-24 -left-24 w-80 h-80 bg-[#2f6af2]/10 rounded-full blur-3xl pointer-events-none"></div>

              {/* Top Stage Badges & Tools */}
              <div className="relative z-10 flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="inline-flex items-center gap-1.5 bg-[#f0eff5] dark:bg-[#25262c] px-3 py-1 rounded-full text-xs font-semibold text-gray-800 dark:text-gray-200 shadow-xs">
                    <span className="material-symbols-outlined text-sm text-[#0071e3] filled">verified</span>
                    اصالت تیتانیوم گرید هوافضا
                  </span>
                  <span className="inline-flex items-center gap-1 bg-[#eeedf3] dark:bg-[#202126] px-2.5 py-1 rounded-full text-xs text-gray-600 dark:text-gray-300">
                    <span className="material-symbols-outlined text-sm">360</span>
                    نمای سه‌بعدی
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsZoomed(prev => !prev)}
                    className={`w-9 h-9 rounded-full flex items-center justify-center transition-all shadow-xs ${
                      isZoomed
                        ? 'bg-[#0071e3] text-white'
                        : 'bg-[#f0eff5] dark:bg-[#25262c] text-gray-600 dark:text-gray-300 hover:text-gray-900'
                    }`}
                    title="بزرگ‌نمایی لنزی"
                  >
                    <span className="material-symbols-outlined text-lg">
                      {isZoomed ? 'zoom_out' : 'zoom_in'}
                    </span>
                  </button>

                  <button
                    onClick={() => toggleFavorite(product.id)}
                    className="w-9 h-9 rounded-full bg-[#f0eff5] dark:bg-[#25262c] text-gray-600 dark:text-gray-300 hover:text-rose-500 flex items-center justify-center transition-all shadow-xs"
                    title="افزودن به علاقه‌مندی"
                  >
                    <span className={`material-symbols-outlined text-lg ${favorite ? 'filled text-rose-500' : ''}`}>
                      favorite
                    </span>
                  </button>
                </div>
              </div>

              {/* Master Display Image Canvas */}
              <div className="relative z-10 w-full aspect-square max-h-[500px] rounded-2xl flex items-center justify-center overflow-hidden cursor-crosshair">
                <img
                  src={currentDisplayImage}
                  alt={product.name}
                  className={`w-full h-full object-contain p-4 sm:p-8 transition-transform duration-300 ease-out origin-center ${
                    isZoomed ? 'scale-150' : 'scale-100'
                  }`}
                />

                {/* Quick Spec Watermark */}
                <div className="absolute bottom-3 left-4 bg-white/80 dark:bg-black/60 backdrop-blur-md px-3 py-1 rounded-full text-gray-500 text-[11px] font-mono tracking-wider flex items-center gap-1.5 shadow-xs border border-white/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#0071e3]"></span>
                  AEROSPACE GRADE Ti-6Al-4V
                </div>
              </div>

              {/* Bottom Micro-spec Floating Capsule */}
              <div className="relative z-10 mt-6 grid grid-cols-3 gap-2 text-center pt-2">
                <div className="p-3 bg-[#f8f7fc] dark:bg-[#22242a] rounded-2xl border border-black/[0.02] dark:border-white/[0.04]">
                  <span className="block text-base font-bold text-gray-900 dark:text-white">15W</span>
                  <span className="text-[11px] text-gray-500 dark:text-gray-400">شارژ بی‌سیم Qi2 سریع</span>
                </div>
                <div className="p-3 bg-[#f8f7fc] dark:bg-[#22242a] rounded-2xl border border-black/[0.02] dark:border-white/[0.04]">
                  <span className="block text-base font-bold text-gray-900 dark:text-white">30W</span>
                  <span className="text-[11px] text-gray-500 dark:text-gray-400">ورودی/خروجی کابل PD</span>
                </div>
                <div className="p-3 bg-[#f8f7fc] dark:bg-[#22242a] rounded-2xl border border-black/[0.02] dark:border-white/[0.04]">
                  <span className="block text-base font-bold text-gray-900 dark:text-white">۹.۸ mm</span>
                  <span className="text-[11px] text-gray-500 dark:text-gray-400">فوق باریک و سبک</span>
                </div>
              </div>
            </div>

            {/* Thumbnails Multi-Angle Reel */}
            <div className="grid grid-cols-4 gap-3 sm:gap-4">
              {galleryItems.map((thumb, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveThumbIndex(idx)}
                  className={`group relative rounded-2xl bg-white dark:bg-[#1a1b1f] p-2 shadow-xs transition-all duration-200 border cursor-pointer ${
                    activeThumbIndex === idx
                      ? 'border-[#0071e3] ring-2 ring-[#0071e3]/20'
                      : 'border-black/[0.04] dark:border-white/[0.06] opacity-70 hover:opacity-100'
                  }`}
                >
                  <div className="aspect-square w-full rounded-xl overflow-hidden bg-[#faf8fe] dark:bg-[#22242a] flex items-center justify-center p-1">
                    <img
                      src={thumb.thumbnail}
                      alt={thumb.caption}
                      className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <span className="block mt-1 text-[11px] text-center text-gray-700 dark:text-gray-300 truncate">
                    {thumb.caption}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Left Column (RTL Purchase Engine) */}
          <div className="lg:col-span-5 flex flex-col gap-6 lg:sticky lg:top-24">
            <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-8 shadow-sm border border-black/[0.04] dark:border-white/[0.06] flex flex-col gap-5 text-right">
              {/* Category & Series Tagline */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#0071e3]"></span>
                  <span className="text-xs font-bold text-[#0071e3] dark:text-[#abc7ff] tracking-wide">
                    {product.brandCategory || 'TECNONET ATELIER SERIES'}
                  </span>
                </div>
                <span className="text-[10px] font-mono bg-[#f0eff5] dark:bg-[#25262c] text-gray-500 dark:text-gray-400 px-2.5 py-0.5 rounded-full">
                  EDITION 2025
                </span>
              </div>

              {/* Title & Tagline */}
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white leading-tight">
                  {product.name}
                </h1>
                <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-300 mt-2 leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Reviews Bar */}
              <div className="flex items-center justify-between pb-2 border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-2">
                  <div className="flex text-amber-500">
                    <span className="material-symbols-outlined text-sm filled">star</span>
                    <span className="material-symbols-outlined text-sm filled">star</span>
                    <span className="material-symbols-outlined text-sm filled">star</span>
                    <span className="material-symbols-outlined text-sm filled">star</span>
                    <span className="material-symbols-outlined text-sm filled">star</span>
                  </div>
                  <span className="text-xs font-bold text-gray-900 dark:text-white">{product.rating}</span>
                  <span className="text-[11px] text-gray-400">
                    ({toPersianDigits(product.reviewCount)} نظر خریداران تایید شده)
                  </span>
                </div>

                <button
                  onClick={() => {
                    setActiveTab('reviews');
                    const el = document.getElementById('deep-tabs-section');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="text-xs font-medium text-[#0071e3] dark:text-[#abc7ff] hover:underline flex items-center gap-0.5"
                >
                  مشاهده نظرات
                  <span className="material-symbols-outlined text-xs">arrow_downward</span>
                </button>
              </div>

              {/* Stock Live Status */}
              <div className="bg-[#f8f7fc] dark:bg-[#22242a] p-3 rounded-2xl flex items-center justify-between border border-black/[0.02] dark:border-white/[0.04]">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-full bg-[#0071e3]/10 text-[#0071e3] flex items-center justify-center">
                    <span className="material-symbols-outlined text-lg">bolt</span>
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-gray-900 dark:text-white">
                      موجود در انبار مرکزی تهران
                    </span>
                    <span className="block text-[11px] text-gray-500 dark:text-gray-400">
                      سفارش تا ساعت ۱۶:۰۰، ارسال فوری امروز
                    </span>
                  </div>
                </div>
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
              </div>

              {/* Dynamic Color Selector */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-gray-900 dark:text-white">رنگ بدنه متالیک:</span>
                  <span className="text-[#0071e3] dark:text-[#abc7ff] font-medium">{selectedColor.name}</span>
                </div>
                <div className="flex items-center gap-3 pt-1">
                  {product.colors.map(col => {
                    const isSelected = selectedColor.id === col.id;
                    return (
                      <button
                        key={col.id}
                        type="button"
                        onClick={() => setSelectedColor(col)}
                        className={`relative w-10 h-10 rounded-full p-0.5 transition-all cursor-pointer ${
                          isSelected ? 'ring-2 ring-[#0071e3] ring-offset-2 scale-110' : 'opacity-70 hover:opacity-100'
                        }`}
                        title={col.name}
                      >
                        <span
                          className={`w-full h-full rounded-full block shadow-sm ${
                            col.gradient ? `bg-gradient-to-br ${col.gradient}` : ''
                          }`}
                          style={{ backgroundColor: col.hex }}
                        />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Capacity Selector (if available) */}
              {product.capacities && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-gray-900 dark:text-white">
                      ظرفیت سلول باتری لیتیوم کبالت:
                    </span>
                    <span className="text-gray-400">ضمانت تعویض ۱۸ ماهه</span>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {product.capacities.map(cap => {
                      const isSelected = selectedCapacity?.id === cap.id;
                      return (
                        <button
                          key={cap.id}
                          type="button"
                          onClick={() => setSelectedCapacity(cap)}
                          className={`p-3 rounded-2xl text-right flex flex-col justify-between transition-all cursor-pointer border ${
                            isSelected
                              ? 'bg-[#f0eff5] dark:bg-[#25262c] border-[#0071e3] shadow-xs'
                              : 'bg-[#faf8fe] dark:bg-[#1e2025] border-transparent opacity-80 hover:opacity-100'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full">
                            <span className="font-bold text-sm text-gray-900 dark:text-white">{cap.label}</span>
                            {isSelected && (
                              <span className="w-4 h-4 rounded-full bg-[#0071e3] text-white flex items-center justify-center text-[10px]">
                                ✓
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-gray-500 dark:text-gray-400 mt-1">{cap.specs}</span>
                          <span className="text-[11px] text-[#0071e3] dark:text-[#abc7ff] font-bold mt-2">
                            {cap.note}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Price Calculation Bay */}
              <div className="bg-[#f8f7fc] dark:bg-[#202126] rounded-2xl p-4 flex flex-col gap-1 border border-black/[0.02] dark:border-white/[0.04]">
                {currentOriginalPrice && (
                  <div className="flex items-center justify-between text-gray-400 line-through text-xs font-mono">
                    <span>قیمت رسمی استودیو:</span>
                    <span>{formatPersianPrice(currentOriginalPrice)} تومان</span>
                  </div>
                )}

                <div className="flex items-baseline justify-between mt-1">
                  <div className="flex items-center gap-2">
                    <span className="bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 text-xs font-bold px-2 py-0.5 rounded-full">
                      ۲۴٪ جشنواره
                    </span>
                    <span className="text-[11px] text-gray-500 dark:text-gray-400">تخفیف مستقیم نقدی</span>
                  </div>

                  <div className="text-left">
                    <span className="text-2xl sm:text-3xl font-extrabold text-[#0071e3] dark:text-[#abc7ff] tracking-tight">
                      {formatPersianPrice(currentPrice)}
                    </span>
                    <span className="text-xs text-gray-700 dark:text-gray-300 mr-1.5 font-bold">تومان</span>
                  </div>
                </div>
              </div>

              {/* Purchase Call-To-Action Cluster */}
              <div className="flex flex-col gap-2.5 pt-1">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  className={`w-full py-3.5 px-6 rounded-full font-bold text-sm shadow-md transition-all transform active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer ${
                    addedBtnState
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[#0071e3] hover:bg-[#005cbb] text-white'
                  }`}
                >
                  <span className="material-symbols-outlined text-xl">
                    {addedBtnState ? 'check_circle' : 'shopping_bag'}
                  </span>
                  <span>{addedBtnState ? 'به سبد خرید اضافه شد!' : 'افزودن به سبد خرید تخصصی'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleInstantBuy}
                  className="w-full py-3 px-6 rounded-full bg-[#f0eff5] dark:bg-[#26282e] hover:bg-[#e4e2e8] dark:hover:bg-[#2f313a] text-gray-900 dark:text-white font-semibold text-xs sm:text-sm transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  <span className="material-symbols-outlined text-lg text-[#0071e3]">flash_on</span>
                  <span>خرید آنی با یک کلیک (تکمیل سریع آدرس)</span>
                </button>
              </div>

              {/* Trust Bulletins */}
              <div className="grid grid-cols-2 gap-2 pt-2 text-gray-500 dark:text-gray-400 text-xs border-t border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-base text-[#0071e3]">security</span>
                  <span>{product.warrantyType}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-base text-[#0071e3]">sync</span>
                  <span>۷ روز ضمانت استرداد کامل وجه</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Deep Exploration Architecture Tabs */}
      <section id="deep-tabs-section" className="max-w-[1380px] w-full mx-auto px-4 sm:px-6 py-10">
        {/* Tab Controls Dock */}
        <div className="bg-white dark:bg-[#1a1b1f] rounded-2xl p-1.5 shadow-xs border border-gray-100 dark:border-gray-800 max-w-2xl mx-auto flex items-center gap-1">
          <button
            onClick={() => setActiveTab('engineering')}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm text-center transition-all cursor-pointer ${
              activeTab === 'engineering'
                ? 'bg-[#f0eff5] dark:bg-[#25262c] text-gray-900 dark:text-white font-bold shadow-xs'
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-white font-medium'
            }`}
          >
            توضیحات و مهندسی ساخت
          </button>
          <button
            onClick={() => setActiveTab('specs')}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm text-center transition-all cursor-pointer ${
              activeTab === 'specs'
                ? 'bg-[#f0eff5] dark:bg-[#25262c] text-gray-900 dark:text-white font-bold shadow-xs'
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-white font-medium'
            }`}
          >
            مشخصات فنی و استانداردها
          </button>
          <button
            onClick={() => setActiveTab('reviews')}
            className={`flex-1 py-2.5 px-3 rounded-xl text-xs sm:text-sm text-center transition-all cursor-pointer ${
              activeTab === 'reviews'
                ? 'bg-[#f0eff5] dark:bg-[#25262c] text-gray-900 dark:text-white font-bold shadow-xs'
                : 'text-gray-500 hover:text-gray-900 dark:hover:text-white font-medium'
            }`}
          >
            دیدگاه‌ها و نظرات ({toPersianDigits(customReviews.length)})
          </button>
        </div>

        {/* Tab Panels */}
        <div className="mt-8 text-right">
          {/* Tab 1: Engineering */}
          {activeTab === 'engineering' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch animate-in fade-in duration-300">
              {/* Bento Highlight 1: Structural Titanium */}
              <div className="lg:col-span-8 bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-10 shadow-xs border border-gray-100 dark:border-gray-800 flex flex-col justify-between overflow-hidden relative group">
                <div className="max-w-xl z-10 space-y-3">
                  <span className="inline-flex items-center gap-1 bg-[#f0eff5] dark:bg-[#25262c] px-3 py-1 rounded-full text-xs text-[#0071e3] dark:text-[#abc7ff] font-mono">
                    MATHEMATICAL PRECISION
                  </span>
                  <h3 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
                    تراش‌کاری پنج محوره CNC از تیتانیوم گرید ۵
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
                    بدنه این اکسسوری از همان آلیاژ تیتانیومی فرم داده شده است که در فضاپیماها به کار می‌رود. مقاومت بی‌نظیر در برابر ضربه و خراشیدگی سطحی همراه با وزن سبک ۱۸۸ گرم، احساس دست‌گرفتن محصولی بدون مرز را تداعی می‌کند. لبه‌های تراش‌خورده میکرومتری از خش افتادن بدنه آیفون شما جلوگیری به عمل می‌آورند.
                  </p>
                </div>

                {/* Visual Asset of Internal Layers */}
                <div className="mt-8 w-full h-64 sm:h-72 rounded-2xl bg-[#faf8fe] dark:bg-[#22242a] overflow-hidden relative flex items-center justify-center border border-black/[0.03] dark:border-white/[0.04]">
                  <img
                    src="https://lh3.googleusercontent.com/aida-public/AB6AXuB0wYzClTbsbnFxt0Eecq13BYN1Bq3vQb7ZNKlT743o2Gg-XMJWi8YrZHdgxNo6pB4XePQxiUg7NUmR_LiXZFMcEYAjtbMEbEM-4PQnoKvKuFuEme21FGxDsSByWuzeYBKWKRVZSePIGEMdn4xnvECakEkKZ39IDqVCtRXf-jX238R_is1tjsOmCJuOrU1_pXggWHzMIvTaG1VLjt13B52QVrSMJ8nP4muePY4PxOwd6aSAC2stbu8R"
                    alt="معماری داخلی پاوربانک و چیپست خنک‌کننده"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent"></div>
                  <div className="absolute bottom-4 right-4 flex items-center gap-2 text-gray-900 dark:text-white text-xs bg-white/90 dark:bg-black/80 backdrop-blur-md px-3.5 py-1.5 rounded-full shadow-xs">
                    <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                    لایه‌های خنک‌کننده نانوگرافین ضد داغی بیش‌ازحد
                  </div>
                </div>
              </div>

              {/* Bento Highlight 2 & 3: Thermal & Wireless Precision */}
              <div className="lg:col-span-4 flex flex-col gap-6">
                <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 shadow-xs border border-gray-100 dark:border-gray-800 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-[#0071e3]/10 text-[#0071e3] flex items-center justify-center mb-3">
                      <span className="material-symbols-outlined text-2xl font-bold">device_thermostat</span>
                    </div>
                    <h4 className="text-base font-bold text-gray-900 dark:text-white">
                      کنترل حرارتی پیوسته با سنسور NTC
                    </h4>
                    <p className="text-xs text-gray-600 dark:text-gray-300 mt-2 leading-relaxed">
                      حسگر حرارتی ۱۰۰ بار در ثانیه دمای گوشی و سلول داخلی را اندازه‌گیری می‌کند تا سلامت باتری دستگاه شما همواره حفظ شود.
                    </p>
                  </div>

                  {/* Interactive Temp Display */}
                  <div className="mt-4 p-3 bg-[#f8f7fc] dark:bg-[#22242a] rounded-2xl border border-black/[0.02] dark:border-white/[0.04]">
                    <div className="flex items-center justify-between text-xs font-mono text-gray-500 mb-2">
                      <span>سنجش دمای لحظه‌ای:</span>
                      <span className="text-[#0071e3] dark:text-[#abc7ff] font-bold">{simulatedTemp}° C</span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 h-2 rounded-full overflow-hidden">
                      <div className="bg-gradient-to-l from-[#005cbb] via-[#0071e3] to-sky-400 h-full w-[45%] rounded-full"></div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSimulatedTemp(prev => (prev === 31.2 ? 29.8 : 31.2))}
                      className="text-[10px] text-[#0071e3] mt-2 block hover:underline"
                    >
                      تست شبیه‌سازی سیستم تهویه فعال
                    </button>
                  </div>
                </div>

                <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 shadow-xs border border-gray-100 dark:border-gray-800 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="w-12 h-12 rounded-2xl bg-[#f0eff5] dark:bg-[#25262c] text-gray-900 dark:text-white flex items-center justify-center mb-3">
                      <span className="material-symbols-outlined text-2xl font-bold">electric_bolt</span>
                    </div>
                    <h4 className="text-base font-bold text-gray-900 dark:text-white">
                      پروتکل نسل جدید Qi2 مگ‌سیف
                    </h4>
                    <p className="text-xs text-gray-600 dark:text-gray-300 mt-2 leading-relaxed">
                      تطبیق مغناطیسی با نیروی ربایش ۱۲ نیوتن (تحمل وزن تا ۱.۴ کیلوگرم بدون جدا شدن)، بهینه‌سازی شده برای سری آیفون ۱۲ تا ۱۶ پرومکس.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 font-mono text-[11px] text-gray-500 dark:text-gray-400 pt-2">
                    <span className="material-symbols-outlined text-base text-[#0071e3]">check_circle</span>
                    <span>تاییدیه رسمی استاندارد شارژ مغناطیسی جهانی</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Specs Matrix */}
          {activeTab === 'specs' && (
            <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-10 shadow-xs border border-gray-100 dark:border-gray-800 animate-in fade-in duration-300 space-y-6">
              <div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                  ماتریس مشخصات مهندسی و فنی کالا
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                  تمامی داده‌های زیر توسط آزمایشگاه کالیبراسیون صنعتی تکنونت استور در شرایط تست استاندارد صحه‌گذاری شده‌اند.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-[#0071e3] dark:text-[#abc7ff] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-base">battery_charging_full</span>
                    مشخصات ولتاژ و درگاه‌ها
                  </h4>
                  <div className="space-y-2 text-xs">
                    {Object.entries(product.specs).map(([key, val]) => (
                      <div
                        key={key}
                        className="flex justify-between items-center p-3 bg-[#f8f7fc] dark:bg-[#22242a] rounded-xl"
                      >
                        <span className="text-gray-500 dark:text-gray-400">{key}</span>
                        <span className="font-bold text-gray-900 dark:text-white font-mono">{val}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-[#0071e3] dark:text-[#abc7ff] flex items-center gap-1.5">
                    <span className="material-symbols-outlined text-base">architecture</span>
                    ابعاد فیزیکی و متریال
                  </h4>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between items-center p-3 bg-[#f8f7fc] dark:bg-[#22242a] rounded-xl">
                      <span className="text-gray-500 dark:text-gray-400">جنس شاسی اصلی</span>
                      <span className="font-bold text-gray-900 dark:text-white">{product.material}</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-[#f8f7fc] dark:bg-[#22242a] rounded-xl">
                      <span className="text-gray-500 dark:text-gray-400">مدت گارانتی</span>
                      <span className="font-bold text-gray-900 dark:text-white">
                        {toPersianDigits(product.warrantyMonths)} ماهه تعویض
                      </span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-[#f8f7fc] dark:bg-[#22242a] rounded-xl">
                      <span className="text-gray-500 dark:text-gray-400">شناسه اختصاصی بارکد</span>
                      <span className="font-bold text-gray-900 dark:text-white font-mono">{product.code}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Inside Box Strip */}
              <div className="pt-4 border-t border-gray-100 dark:border-gray-800">
                <span className="text-xs font-bold text-gray-900 dark:text-white block mb-2">
                  محتویات داخل جعبه استودیویی:
                </span>
                <div className="flex flex-wrap gap-4 text-xs text-gray-600 dark:text-gray-300">
                  {product.boxContents.map((item, i) => (
                    <span key={i} className="flex items-center gap-1.5 bg-[#f0eff5] dark:bg-[#25262c] px-3 py-1 rounded-full">
                      <span className="material-symbols-outlined text-base text-[#0071e3]">check</span>
                      <span>{item}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Reviews */}
          {activeTab === 'reviews' && (
            <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-10 shadow-xs border border-gray-100 dark:border-gray-800 animate-in fade-in duration-300 space-y-8">
              {/* Rating Summary Header */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center pb-6 border-b border-gray-100 dark:border-gray-800">
                <div className="md:col-span-4 text-center md:text-right space-y-1">
                  <span className="text-4xl sm:text-5xl font-extrabold text-gray-900 dark:text-white">
                    {product.rating}
                  </span>
                  <div className="flex items-center justify-center md:justify-start text-amber-500 gap-1 my-1">
                    <span className="material-symbols-outlined text-xl filled">star</span>
                    <span className="material-symbols-outlined text-xl filled">star</span>
                    <span className="material-symbols-outlined text-xl filled">star</span>
                    <span className="material-symbols-outlined text-xl filled">star</span>
                    <span className="material-symbols-outlined text-xl filled">star</span>
                  </div>
                  <p className="text-xs text-gray-500">
                    بر اساس {toPersianDigits(product.reviewCount)} ارزیابی ثبت شده خریداران رسمی
                  </p>
                </div>

                <div className="md:col-span-8 space-y-2">
                  <div className="flex items-center gap-3 text-xs">
                    <span className="w-12 text-gray-400">۵ ستاره</span>
                    <div className="flex-1 bg-gray-100 dark:bg-gray-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-400 h-full w-[91%] rounded-full"></div>
                    </div>
                    <span className="w-8 text-left font-mono font-bold text-gray-700 dark:text-gray-300">۹۱٪</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="w-12 text-gray-400">۴ ستاره</span>
                    <div className="flex-1 bg-gray-100 dark:bg-gray-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-400 h-full w-[7%] rounded-full"></div>
                    </div>
                    <span className="w-8 text-left font-mono font-bold text-gray-700 dark:text-gray-300">۷٪</span>
                  </div>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="w-12 text-gray-400">۳ ستاره</span>
                    <div className="flex-1 bg-gray-100 dark:bg-gray-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-400 h-full w-[2%] rounded-full"></div>
                    </div>
                    <span className="w-8 text-left font-mono font-bold text-gray-700 dark:text-gray-300">۲٪</span>
                  </div>
                </div>
              </div>

              {/* Review Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {customReviews.map(rev => (
                  <div
                    key={rev.id}
                    className="bg-[#f8f7fc] dark:bg-[#22242a] p-4 rounded-2xl flex flex-col justify-between border border-black/[0.02] dark:border-white/[0.04]"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2.5">
                          <div
                            className={`w-9 h-9 rounded-full ${rev.avatarColor} font-bold text-xs flex items-center justify-center`}
                          >
                            {rev.initials}
                          </div>
                          <div>
                            <span className="block text-xs font-bold text-gray-900 dark:text-white">
                              {rev.author}
                            </span>
                            <span className="block text-[10px] text-gray-400">
                              {rev.variantPurchased} • {rev.date}
                            </span>
                          </div>
                        </div>

                        <div className="flex text-amber-500">
                          {Array.from({ length: rev.rating }).map((_, i) => (
                            <span key={i} className="material-symbols-outlined text-xs filled">
                              star
                            </span>
                          ))}
                        </div>
                      </div>

                      <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed pt-1">
                        {rev.comment}
                      </p>
                    </div>

                    <div className="flex items-center gap-1.5 text-gray-400 text-[10px] mt-4 pt-2 border-t border-black/[0.04] dark:border-white/[0.04]">
                      <span className="material-symbols-outlined text-xs text-emerald-600">verified_user</span>
                      <span>خرید تایید شده از تکنونت استور</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add New Review Form */}
              <form onSubmit={handleReviewSubmit} className="pt-6 border-t border-gray-100 dark:border-gray-800 space-y-3">
                <h4 className="text-sm font-bold text-gray-900 dark:text-white">ثبت دیدگاه تخصصی جدید</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input
                    type="text"
                    required
                    value={newReviewAuthor}
                    onChange={e => setNewReviewAuthor(e.target.value)}
                    placeholder="نام و نام خانوادگی شما"
                    className="text-xs p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3]"
                  />
                  <div className="flex items-center justify-between px-3 py-2 rounded-xl border border-gray-200 dark:border-gray-700 text-xs">
                    <span className="text-gray-500">امتیاز شما:</span>
                    <div className="flex gap-1 text-amber-500">
                      {[1, 2, 3, 4, 5].map(star => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewReviewRating(star)}
                          className="focus:outline-none"
                        >
                          <span
                            className={`material-symbols-outlined text-lg ${
                              star <= newReviewRating ? 'filled' : ''
                            }`}
                          >
                            star
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <textarea
                  rows={3}
                  required
                  value={newReviewComment}
                  onChange={e => setNewReviewComment(e.target.value)}
                  placeholder="تجربه فنی شما در مورد کیفیت ساخت تیتانیوم، قدرت آهنربا و عملکرد شارژ..."
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3]"
                />

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-[#0071e3] text-white rounded-full text-xs font-bold hover:bg-[#005cbb] transition-colors shadow-xs"
                >
                  ارسال و ثبت دیدگاه
                </button>
              </form>
            </div>
          )}
        </div>
      </section>

      {/* Curated Complementary Ecosystem Accessories */}
      <section className="max-w-[1380px] w-full mx-auto px-4 sm:px-6 py-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-6 gap-3">
          <div className="text-right">
            <div className="flex items-center gap-1.5 text-[#0071e3] dark:text-[#abc7ff] text-xs font-bold mb-1">
              <span className="material-symbols-outlined text-base">view_in_ar</span>
              <span>اکوسیستم یکپارچه مگ‌سیف</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
              محصولات مکمل و تجهیزات جانبی پیشنهادی
            </h2>
          </div>
          <button
            onClick={() => setActivePage('store')}
            className="text-xs font-bold text-[#0071e3] dark:text-[#abc7ff] hover:underline flex items-center gap-1 self-start sm:self-auto cursor-pointer"
          >
            <span>مشاهده تمامی اکسسوری‌های سری Mag</span>
            <span className="material-symbols-outlined text-base">chevron_left</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {complementaryProducts.map(comp => (
            <div
              key={comp.id}
              className="group bg-white dark:bg-[#1a1b1f] rounded-3xl p-4 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between border border-black/[0.03] dark:border-white/[0.04]"
            >
              <div>
                <div
                  onClick={() => openProductDetail(comp.id)}
                  className="relative w-full aspect-square rounded-2xl bg-[#faf8fe] dark:bg-[#22242a] overflow-hidden flex items-center justify-center p-4 cursor-pointer"
                >
                  {comp.badge && (
                    <span className="absolute top-3 right-3 bg-white/90 dark:bg-black/60 backdrop-blur-md px-2.5 py-0.5 rounded-full text-[10px] font-bold text-[#0071e3] dark:text-[#abc7ff]">
                      {comp.badge}
                    </span>
                  )}
                  <img
                    src={comp.image}
                    alt={comp.name}
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                  />
                </div>

                <div className="mt-4 space-y-1 text-right">
                  <span className="text-[11px] text-gray-400">{comp.categoryLabel}</span>
                  <h3
                    onClick={() => openProductDetail(comp.id)}
                    className="text-sm font-bold text-gray-900 dark:text-white group-hover:text-[#0071e3] transition-colors line-clamp-1 cursor-pointer"
                  >
                    {comp.name}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2">
                    {comp.description}
                  </p>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
                <div className="text-right">
                  <span className="text-sm font-bold text-gray-900 dark:text-white">
                    {formatPersianPrice(comp.price)}
                  </span>
                  <span className="text-[11px] text-gray-400 mr-1">تومان</span>
                </div>

                <button
                  onClick={() => addToCart(comp)}
                  className="w-10 h-10 rounded-full bg-[#f0eff5] dark:bg-[#25262c] hover:bg-[#0071e3] hover:text-white text-gray-900 dark:text-white flex items-center justify-center transition-colors shadow-xs"
                  title="افزودن سریع"
                >
                  <span className="material-symbols-outlined text-lg">add_shopping_cart</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
