import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { toPersianDigits } from '../utils/formatters';

export const Header: React.FC = () => {
  const {
    activePage,
    setActivePage,
    cartTotalCount,
    isDarkMode,
    toggleDarkMode,
    setIsSearchOpen,
    favorites,
  } = useStore();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#faf8fe]/85 dark:bg-[#121316]/85 backdrop-blur-xl border-b border-black/[0.04] dark:border-white/[0.08] shadow-[0_1px_8px_rgba(0,0,0,0.03)] transition-colors duration-200">
      <div className="h-20 max-w-[1380px] mx-auto px-4 sm:px-6 flex items-center justify-between gap-4">
        {/* Right side (RTL Brand & Nav) */}
        <div className="flex items-center gap-6 xl:gap-8">
          {/* Brand Wordmark & Logo */}
          <button
            onClick={() => setActivePage('home')}
            className="flex items-center gap-2.5 group focus:outline-none"
            aria-label="تکنونت استور - صفحه اصلی"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#005cbb] to-[#0071e3] text-white flex items-center justify-center shadow-md shadow-[#0071e3]/20 group-hover:scale-105 transition-transform duration-200">
              <span className="material-symbols-outlined text-2xl font-bold">bolt</span>
            </div>
            <div className="flex flex-col text-right">
              <span className="text-xl font-bold tracking-tight text-[#1a1b1f] dark:text-white flex items-center gap-1.5">
                تکنونت
                <span className="text-[10px] font-mono font-medium px-1.5 py-0.2 rounded bg-[#0071e3]/10 dark:bg-[#0071e3]/25 text-[#0071e3] dark:text-[#abc7ff]">
                  ATELIER
                </span>
              </span>
              <span className="text-[10px] text-gray-500 dark:text-gray-400 font-sans tracking-wide">
                TecnoNet Gadgets
              </span>
            </div>
          </button>

          {/* Nav Links (Desktop) */}
          <nav className="hidden lg:flex items-center gap-1">
            <button
              onClick={() => setActivePage('home')}
              className={`px-3.5 py-1.5 text-sm font-medium rounded-full transition-all ${
                activePage === 'home'
                  ? 'bg-[#0071e3] text-white font-semibold shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800/60'
              }`}
            >
              خانه
            </button>
            <button
              onClick={() => setActivePage('store')}
              className={`px-3.5 py-1.5 text-sm font-medium rounded-full transition-all ${
                activePage === 'store' || activePage === 'product-detail'
                  ? 'bg-[#0071e3] text-white font-semibold shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800/60'
              }`}
            >
              فروشگاه و محصولات
            </button>
            <button
              onClick={() => setActivePage('categories')}
              className={`px-3.5 py-1.5 text-sm font-medium rounded-full transition-all ${
                activePage === 'categories'
                  ? 'bg-[#0071e3] text-white font-semibold shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800/60'
              }`}
            >
              دسته‌بندی‌ها
            </button>
            <button
              onClick={() => setActivePage('favorites')}
              className={`px-3.5 py-1.5 text-sm font-medium rounded-full transition-all relative ${
                activePage === 'favorites'
                  ? 'bg-[#0071e3] text-white font-semibold shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800/60'
              }`}
            >
              علاقه‌مندی‌ها
              {favorites.length > 0 && (
                <span className="inline-flex mr-1.5 px-1.5 py-0.2 text-[10px] rounded-full bg-rose-500 text-white font-bold">
                  {toPersianDigits(favorites.length)}
                </span>
              )}
            </button>
            <button
              onClick={() => setActivePage('support')}
              className={`px-3.5 py-1.5 text-sm font-medium rounded-full transition-all ${
                activePage === 'support'
                  ? 'bg-[#0071e3] text-white font-semibold shadow-sm'
                  : 'text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white hover:bg-gray-100 dark:hover:bg-gray-800/60'
              }`}
            >
              پشتیبانی مهندسی
            </button>
          </nav>
        </div>

        {/* Left side (Action Controls) */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Search trigger */}
          <button
            onClick={() => setIsSearchOpen(true)}
            aria-label="جستجوی سریع محصولات"
            className="flex items-center gap-2 bg-[#eeedf3] dark:bg-[#1f2024] hover:bg-[#e3e2e7] dark:hover:bg-[#2b2c32] text-gray-700 dark:text-gray-200 px-3.5 py-2 rounded-full transition-all text-xs"
          >
            <span className="material-symbols-outlined text-lg text-gray-500 dark:text-gray-400">search</span>
            <span className="hidden sm:inline text-gray-500 dark:text-gray-400">جستجو در محصولات...</span>
            <span className="hidden md:inline bg-white dark:bg-[#2f3034] text-gray-600 dark:text-gray-300 text-[10px] font-mono px-1.5 py-0.5 rounded shadow-xs">
              ⌘K
            </span>
          </button>

          {/* Dark / Light Mode Switch */}
          <button
            onClick={toggleDarkMode}
            aria-label={isDarkMode ? 'فعال‌سازی حالت روشن' : 'فعال‌سازی حالت تاریک'}
            className="w-10 h-10 rounded-full flex items-center justify-center text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            title={isDarkMode ? 'حالت روشن' : 'حالت تاریک'}
          >
            <span className="material-symbols-outlined text-xl">
              {isDarkMode ? 'light_mode' : 'dark_mode'}
            </span>
          </button>

          {/* Shopping Bag Button */}
          <button
            onClick={() => setActivePage('cart')}
            aria-label="سبد خرید"
            className="relative w-10 h-10 rounded-full flex items-center justify-center text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            title="مشاهده سبد خرید"
          >
            <span className="material-symbols-outlined text-2xl">shopping_bag</span>
            {cartTotalCount > 0 && (
              <span className="absolute top-1 left-1 w-5 h-5 bg-[#0071e3] text-white font-bold text-[11px] rounded-full flex items-center justify-center shadow-sm animate-pulse">
                {toPersianDigits(cartTotalCount)}
              </span>
            )}
          </button>

          {/* User profile avatar / VIP club */}
          <button
            onClick={() => setActivePage('support')}
            aria-label="حساب کاربری باشگاه مشتریان تکنونت"
            className="hidden sm:flex items-center gap-1.5 rounded-full p-1 hover:ring-2 hover:ring-[#0071e3]/30 transition-all"
            title="باشگاه مشتریان VIP تکنونت"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-white font-bold flex items-center justify-center text-xs shadow-sm">
              VIP
            </div>
            <span className="material-symbols-outlined text-base text-gray-500 dark:text-gray-400">
              expand_more
            </span>
          </button>

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(prev => !prev)}
            aria-label="منوی موبایل"
            className="lg:hidden w-10 h-10 rounded-full flex items-center justify-center text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
          >
            <span className="material-symbols-outlined text-2xl">
              {mobileMenuOpen ? 'close' : 'menu'}
            </span>
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#faf8fe] dark:bg-[#121316] border-b border-black/[0.06] dark:border-white/[0.08] px-4 py-4 space-y-2 shadow-lg animate-in slide-in-from-top duration-200">
          <button
            onClick={() => {
              setActivePage('home');
              setMobileMenuOpen(false);
            }}
            className={`w-full text-right px-4 py-2.5 rounded-xl text-sm font-medium flex items-center justify-between ${
              activePage === 'home'
                ? 'bg-[#0071e3] text-white'
                : 'text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <span>خانه</span>
            <span className="material-symbols-outlined text-base">home</span>
          </button>
          <button
            onClick={() => {
              setActivePage('store');
              setMobileMenuOpen(false);
            }}
            className={`w-full text-right px-4 py-2.5 rounded-xl text-sm font-medium flex items-center justify-between ${
              activePage === 'store'
                ? 'bg-[#0071e3] text-white'
                : 'text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <span>فروشگاه و محصولات</span>
            <span className="material-symbols-outlined text-base">inventory_2</span>
          </button>
          <button
            onClick={() => {
              setActivePage('categories');
              setMobileMenuOpen(false);
            }}
            className={`w-full text-right px-4 py-2.5 rounded-xl text-sm font-medium flex items-center justify-between ${
              activePage === 'categories'
                ? 'bg-[#0071e3] text-white'
                : 'text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <span>دسته‌بندی‌های تخصصی</span>
            <span className="material-symbols-outlined text-base">category</span>
          </button>
          <button
            onClick={() => {
              setActivePage('favorites');
              setMobileMenuOpen(false);
            }}
            className={`w-full text-right px-4 py-2.5 rounded-xl text-sm font-medium flex items-center justify-between ${
              activePage === 'favorites'
                ? 'bg-[#0071e3] text-white'
                : 'text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <span>علاقه‌مندی‌ها</span>
            <span className="material-symbols-outlined text-base">favorite</span>
          </button>
          <button
            onClick={() => {
              setActivePage('support');
              setMobileMenuOpen(false);
            }}
            className={`w-full text-right px-4 py-2.5 rounded-xl text-sm font-medium flex items-center justify-between ${
              activePage === 'support'
                ? 'bg-[#0071e3] text-white'
                : 'text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800'
            }`}
          >
            <span>پشتیبانی و استعلام اصالت</span>
            <span className="material-symbols-outlined text-base">verified</span>
          </button>
        </div>
      )}
    </header>
  );
};
