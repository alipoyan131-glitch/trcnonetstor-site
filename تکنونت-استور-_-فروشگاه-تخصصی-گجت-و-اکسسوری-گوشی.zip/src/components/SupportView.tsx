import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { toPersianDigits } from '../utils/formatters';

export const SupportView: React.FC = () => {
  const { showToast } = useStore();
  const [serialQuery, setSerialQuery] = useState('');
  const [serialResult, setSerialResult] = useState<{
    found: boolean;
    model?: string;
    warrantyStatus?: string;
    remainingMonths?: number;
    issueDate?: string;
  } | null>(null);

  // Chat simulator state
  const [chatMessages, setChatMessages] = useState<
    { sender: 'bot' | 'user'; text: string; time: string }[]
  >([
    {
      sender: 'bot',
      text: 'سلام! من مهندس پشتیبانی فنی تکنونت استور هستم. هر سوالی در رابطه با سازگاری تجهیزات مگ‌سیف، شارژرهای GaN یا اصالت تیتانیوم دارید در خدمتم.',
      time: 'هم‌اکنون',
    },
  ]);
  const [chatInput, setChatInput] = useState('');

  const handleSerialCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!serialQuery.trim()) return;

    const code = serialQuery.trim().toUpperCase();
    if (code.includes('TCN') || code.includes('MP') || code.includes('TITAN')) {
      setSerialResult({
        found: true,
        model: 'پاوربانک وایرلس مگ‌سیف تیتانیومی MagPro سری آتلیه',
        warrantyStatus: 'فعال و تحت پوشش طلایی ۱۸ ماهه تکنونت',
        remainingMonths: 17,
        issueDate: 'شهریور ۱۴۰۳',
      });
      showToast('گواهی اصالت و گارانتی طلایی معتبر تایید شد.');
    } else {
      setSerialResult({
        found: true,
        model: `کالای ثبت شده با کد ${code}`,
        warrantyStatus: 'فعال در پایگاه داده رسمی تکنونت استور (گارانتی معتبر)',
        remainingMonths: 14,
        issueDate: 'مرداد ۱۴۰۳',
      });
      showToast('شناسه کالا در سیستم ثبت مرکزی تایید شد.');
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;

    const userText = chatInput;
    const newMsg = {
      sender: 'user' as const,
      text: userText,
      time: 'لحظاتی پیش',
    };

    setChatMessages(prev => [...prev, newMsg]);
    setChatInput('');

    setTimeout(() => {
      let reply = 'بله، تمامی شارژرها و پاوربانک‌های مگ‌سیف تکنونت کاملاً با سری آیفون ۱۲ تا ۱۶ پرومکس و استاندارد رسمی Qi2 سازگار هستند.';
      const lower = userText.toLowerCase();
      if (lower.includes('قیمت') || lower.includes('تخفیف')) {
        reply = 'در جشنواره پاییزه تکنونت، کد تخفیف TECNO500 مبلغ ۵۰۰,۰۰۰ تومان کسر هدیه روی سبد خرید شما اعمال می‌کند.';
      } else if (lower.includes('ارسال') || lower.includes('پست')) {
        reply = 'برای سفارش‌های بالاتر از ۱ میلیون تومان، ارسال اکسپرس و بیمه‌شده کاملاً رایگان است. سفارش‌های تهران در همان روز تحویل می‌شوند.';
      } else if (lower.includes('تیتانیوم') || lower.includes('کیفیت')) {
        reply = 'شاسی محصولات سری آتلیه از آلیاژ تیتانیوم گرید ۵ فرم داده شده است که رسانایی حرارتی بسیار بالا و دفع گرمای عالی در حین شارژ سریع دارد.';
      }

      setChatMessages(prev => [
        ...prev,
        {
          sender: 'bot' as const,
          text: reply,
          time: 'هم‌اکنون',
        },
      ]);
    }, 600);
  };

  return (
    <div className="w-full pb-20 pt-6">
      <div className="max-w-[1380px] mx-auto px-4 sm:px-6 space-y-12">
        {/* Banner */}
        <div className="text-right space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] text-xs font-bold">
            <span className="material-symbols-outlined text-sm">support_agent</span>
            <span>مرکز خدمات پس از فروش و اصالت‌سنجی</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white">
            پشتیبانی مهندسی و استعلام رسمی گارانتی
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 max-w-xl">
            پیگیری سلامت فیزیکی، اصالت متریال و راهنمایی تخصصی پیرامون پروتکل‌های Qi2 و شارژ سریع
          </p>
        </div>

        {/* 2 Grid Columns: Warranty Checker + Live Engineering Chat */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Warranty Checker (6 cols) */}
          <div className="lg:col-span-6 bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-8 shadow-xs border border-gray-100 dark:border-gray-800 space-y-6 text-right">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-[#0071e3]/10 text-[#0071e3] flex items-center justify-center mb-3">
                <span className="material-symbols-outlined text-2xl font-bold">verified_user</span>
              </div>
              <h2 className="text-lg font-bold text-gray-900 dark:text-white">
                سامانه استعلام آنلاین گارانتی و اصالت
              </h2>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 leading-relaxed">
                شماره سریال درج شده روی جعبه، هولوگرام طلایی یا شناسه فاکتور را وارد فرمایید تا وضعیت پوشش گارانتی و تاریخ انقضا مشخص گردد.
              </p>
            </div>

            <form onSubmit={handleSerialCheck} className="space-y-3">
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  value={serialQuery}
                  onChange={e => setSerialQuery(e.target.value)}
                  placeholder="مثال: TCN-MP10-TITAN یا شماره فاکتور"
                  className="flex-1 text-xs p-3 rounded-2xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3] font-mono text-left"
                />
                <button
                  type="submit"
                  className="bg-[#0071e3] text-white px-6 rounded-2xl text-xs font-bold hover:bg-[#005cbb] transition-colors shadow-xs cursor-pointer whitespace-nowrap"
                >
                  استعلام
                </button>
              </div>
              <p className="text-[11px] text-gray-400">
                کدهای نمونه: <span className="font-mono text-[#0071e3]">TCN-MP10-TITAN</span> یا <span className="font-mono text-[#0071e3]">TCN-MS3-PRO</span>
              </p>
            </form>

            {serialResult && (
              <div className="p-4 bg-[#f8f7fc] dark:bg-[#25262c] rounded-2xl space-y-3 border border-emerald-500/30 animate-in fade-in duration-300">
                <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-xs">
                  <span className="material-symbols-outlined text-base">check_circle</span>
                  <span>گواهی اصالت کالا تایید شده است</span>
                </div>

                <div className="space-y-1 text-xs text-gray-700 dark:text-gray-300">
                  <p>
                    <span className="text-gray-400">عنوان کالا:</span> {serialResult.model}
                  </p>
                  <p>
                    <span className="text-gray-400">وضعیت گارانتی:</span> {serialResult.warrantyStatus}
                  </p>
                  <p>
                    <span className="text-gray-400">مدت باقیمانده:</span>{' '}
                    {toPersianDigits(serialResult.remainingMonths || 18)} ماه
                  </p>
                  <p>
                    <span className="text-gray-400">تاریخ ثبت اولیه:</span> {serialResult.issueDate}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Live Engineering Chat (6 cols) */}
          <div className="lg:col-span-6 bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-8 shadow-xs border border-gray-100 dark:border-gray-800 space-y-4 text-right flex flex-col justify-between h-[480px]">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#0071e3]/10 text-[#0071e3] flex items-center justify-center font-bold">
                    <span className="material-symbols-outlined text-xl">engineering</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-gray-900 dark:text-white">
                      گفتگوی آنلاین با مهندس سخت‌افزار
                    </h3>
                    <span className="flex items-center gap-1.5 text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                      پاسخگویی فعال
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Messages box */}
            <div className="flex-1 overflow-y-auto space-y-3 p-2 text-xs">
              {chatMessages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] p-3 rounded-2xl leading-relaxed ${
                      msg.sender === 'user'
                        ? 'bg-[#0071e3] text-white rounded-br-none'
                        : 'bg-[#f0eff5] dark:bg-[#25262c] text-gray-800 dark:text-gray-200 rounded-bl-none'
                    }`}
                  >
                    {msg.text}
                  </div>
                  <span className="text-[10px] text-gray-400 mt-1 px-1">{msg.time}</span>
                </div>
              ))}
            </div>

            {/* Chat input */}
            <form onSubmit={handleSendMessage} className="flex gap-2 pt-2 border-t border-gray-100 dark:border-gray-800">
              <input
                type="text"
                value={chatInput}
                onChange={e => setChatInput(e.target.value)}
                placeholder="سوال فنی خود را بپرسید (مثلا درباره سازگاری با آیفون)..."
                className="flex-1 text-xs p-3 rounded-2xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3]"
              />
              <button
                type="submit"
                className="w-11 h-11 bg-[#0071e3] text-white rounded-2xl flex items-center justify-center hover:bg-[#005cbb] transition-colors cursor-pointer flex-shrink-0"
              >
                <span className="material-symbols-outlined text-lg">send</span>
              </button>
            </form>
          </div>
        </div>

        {/* Technical FAQ Accordions */}
        <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-10 shadow-xs border border-gray-100 dark:border-gray-800 text-right space-y-6">
          <div>
            <h2 className="text-xl font-bold text-gray-900 dark:text-white">
              سوالات پرتکرار و نکات فنی گجت‌ها
            </h2>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              پاسخ به سوالات متداول خریداران پیرامون اصالت، گارانتی و نحوه نگهداری
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-[#f8f7fc] dark:bg-[#22242a] rounded-2xl space-y-1.5">
              <h4 className="font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#0071e3] text-base">help</span>
                استاندارد Qi2 چیست و چه فرقی با شارژرهای معمولی دارد؟
              </h4>
              <p className="text-gray-500 dark:text-gray-400 leading-relaxed">
                استاندارد جهانی Qi2 با همکاری اپل بر پایه مگ‌سیف توسعه یافته است. این فناوری اجازه می‌دهد توان شارژ تا ۱۵ وات واقعی با تراز مغناطیسی بی‌نقص بدون ایجاد حرارت اضافی به باتری گوشی منتقل شود.
              </p>
            </div>

            <div className="p-4 bg-[#f8f7fc] dark:bg-[#22242a] rounded-2xl space-y-1.5">
              <h4 className="font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#0071e3] text-base">help</span>
                چرا بدنه اکسسوری‌های تکنونت از تیتانیوم گرید ۵ است؟
              </h4>
              <p className="text-gray-500 dark:text-gray-400 leading-relaxed">
                تیتانیوم گرید هوافضا Ti-6Al-4V مقاومت خارق‌العاده‌ای در برابر ضربه و خط‌وخش دارد و همزمان به عنوان یک رادیاتور طبیعی حرارت باتری را تخلیه کرده و وزن کالا را به حداقل می‌رساند.
              </p>
            </div>

            <div className="p-4 bg-[#f8f7fc] dark:bg-[#22242a] rounded-2xl space-y-1.5">
              <h4 className="font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#0071e3] text-base">help</span>
                شرایط مهلت تست ۷ روزه بازگشت کالا چیست؟
              </h4>
              <p className="text-gray-500 dark:text-gray-400 leading-relaxed">
                شما از تاریخ تحویل مرسوله، ۷ روز تمام فرصت دارید تا عملکرد فنی کالا را بررسی کنید. در صورت هرگونه عدم رضایت، هزینه بدون کسر کارمزد مسترد خواهد شد.
              </p>
            </div>

            <div className="p-4 bg-[#f8f7fc] dark:bg-[#22242a] rounded-2xl space-y-1.5">
              <h4 className="font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                <span className="material-symbols-outlined text-[#0071e3] text-base">help</span>
                نحوه ارسال و تحویل فوری چگونه است؟
              </h4>
              <p className="text-gray-500 dark:text-gray-400 leading-relaxed">
                سفارش‌های ثبت شده تا ساعت ۱۶ برای استان تهران در همان روز با پیک اختصاصی تحویل می‌شوند. برای سایر استان‌ها نیز ارسال از طریق پست پیشتاز بیمه‌شده ۲۴ تا ۴۸ ساعته انجام می‌شود.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
