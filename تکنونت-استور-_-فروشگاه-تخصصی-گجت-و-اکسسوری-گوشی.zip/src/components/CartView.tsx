import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { formatPersianPrice, toPersianDigits } from '../utils/formatters';

export const CartView: React.FC = () => {
  const {
    cart,
    updateCartQuantity,
    removeFromCart,
    savedForLater,
    saveForLater,
    moveToCartFromSaved,
    cartTotalCount,
    cartSubtotal,
    cartDiscount,
    voucherDiscount,
    appliedCoupon,
    applyCouponCode,
    clearCart,
    setActivePage,
    openProductDetail,
    showToast,
  } = useStore();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [couponInput, setCouponInput] = useState('');
  const [couponError, setCouponError] = useState<string | null>(null);

  // Step 2 Form States
  const [recipientName, setRecipientName] = useState('علی پویا');
  const [recipientPhone, setRecipientPhone] = useState('۰۹۱۲۳۴۵۶۷۸۹');
  const [recipientCity, setRecipientCity] = useState('تهران');
  const [recipientAddress, setRecipientAddress] = useState('سعادت‌آباد، میدان کاج، خیابان مروارید، پلاک ۱۲، واحد ۴');
  const [deliverySlot, setDeliverySlot] = useState('امروز بعدازظهر (ساعت ۱۶ تا ۲۰) - ارسال اختصاصی');
  const [paymentType, setPaymentType] = useState<'shetab' | 'installment' | 'vip'>('shetab');
  const [orderTrackingCode, setOrderTrackingCode] = useState('');

  const finalPayable = Math.max(0, cartSubtotal - cartDiscount - voucherDiscount);

  const handleApplyCoupon = () => {
    if (!couponInput.trim()) return;
    const res = applyCouponCode(couponInput);
    if (!res.success) {
      setCouponError(res.message);
    } else {
      setCouponError(null);
      setCouponInput('');
    }
  };

  const handleProceedToStep2 = () => {
    if (cart.length === 0) {
      showToast('سبد خرید شما خالی است.');
      return;
    }
    setStep(2);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFinalPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const tracking = 'TCN-' + Math.floor(100000 + Math.random() * 900000);
    setOrderTrackingCode(tracking);
    setStep(3);
    clearCart();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    showToast('پرداخت و ثبت سفارش با موفقیت انجام شد!');
  };

  return (
    <div className="w-full pb-20">
      {/* Progress Header Rail */}
      <section className="max-w-[1380px] w-full mx-auto px-4 sm:px-6 pt-6 pb-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1 text-right">
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <button onClick={() => setActivePage('home')} className="hover:text-[#0071e3]">
                فروشگاه
              </button>
              <span className="material-symbols-outlined text-sm">chevron_left</span>
              <span className="text-gray-900 dark:text-white font-semibold">سبد سفارش مدرن</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white tracking-tight">
              {step === 1 && 'سبد خرید شما'}
              {step === 2 && 'اطلاعات تحویل و آدرس گیرنده'}
              {step === 3 && 'رسید نهایی و پیگیری سفارش'}
            </h1>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
              {step === 1 && 'بررسی دقیق مشخصات مهندسی و نهایی‌سازی تجهیزات انتخابی'}
              {step === 2 && 'مشخصات پستی و بازه زمانی تحویل کالا در سراسر کشور'}
              {step === 3 && 'سفارش شما با موفقیت ثبت شد و در حال آماده‌سازی بسته‌بندی است'}
            </p>
          </div>

          {/* Checkout Step Indicator */}
          <div className="inline-flex items-center gap-2 bg-[#f0eff5] dark:bg-[#1a1b1f] px-4 py-2 rounded-full border border-black/[0.02] dark:border-white/[0.04]">
            <div
              className={`flex items-center gap-1.5 text-xs font-semibold ${
                step >= 1 ? 'text-[#0071e3] dark:text-[#abc7ff]' : 'text-gray-400'
              }`}
            >
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  step >= 1 ? 'bg-[#0071e3] text-white' : 'bg-gray-200 dark:bg-gray-700'
                }`}
              >
                ۱
              </span>
              <span>بررسی سبد</span>
            </div>

            <span className="w-4 h-0.5 bg-gray-300 dark:bg-gray-700"></span>

            <div
              className={`flex items-center gap-1.5 text-xs font-semibold ${
                step >= 2 ? 'text-[#0071e3] dark:text-[#abc7ff]' : 'text-gray-400'
              }`}
            >
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  step >= 2 ? 'bg-[#0071e3] text-white' : 'bg-gray-200 dark:bg-gray-700'
                }`}
              >
                ۲
              </span>
              <span>آدرس و زمان ارسال</span>
            </div>

            <span className="w-4 h-0.5 bg-gray-300 dark:bg-gray-700"></span>

            <div
              className={`flex items-center gap-1.5 text-xs font-semibold ${
                step === 3 ? 'text-[#0071e3] dark:text-[#abc7ff]' : 'text-gray-400'
              }`}
            >
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  step === 3 ? 'bg-[#0071e3] text-white' : 'bg-gray-200 dark:bg-gray-700'
                }`}
              >
                ۳
              </span>
              <span>پرداخت امن</span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content Area */}
      <section className="max-w-[1380px] w-full mx-auto px-4 sm:px-6 pb-12">
        {step === 3 ? (
          /* Step 3: Success Confirmation Screen */
          <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-8 sm:p-12 shadow-sm border border-gray-100 dark:border-gray-800 text-center max-w-2xl mx-auto space-y-6 animate-in zoom-in-95 duration-300">
            <div className="w-20 h-20 rounded-full bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
              <span className="material-symbols-outlined text-5xl font-bold">verified</span>
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                سفارش شما با موفقیت ثبت و تایید شد!
              </h2>
              <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 max-w-md mx-auto leading-relaxed">
                بسته شما توسط واحد لجستیک تکنونت استور به آدرس «{recipientAddress}» با بسته‌بندی مقاوم ضدضربه ارسال خواهد شد.
              </p>
            </div>

            <div className="p-4 bg-[#f8f7fc] dark:bg-[#25262c] rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 border border-black/[0.02] dark:border-white/[0.04]">
              <div className="text-right">
                <span className="text-[11px] text-gray-400 block">شناسه رهگیری پستی شاپرک / تکنونت:</span>
                <span className="text-base font-mono font-bold text-[#0071e3] dark:text-[#abc7ff]">
                  {orderTrackingCode}
                </span>
              </div>
              <div className="text-left">
                <span className="text-[11px] text-gray-400 block">زمان تحویل مقرر:</span>
                <span className="text-xs font-bold text-gray-900 dark:text-white">{deliverySlot}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-2">
              <button
                onClick={() => {
                  setStep(1);
                  setActivePage('store');
                }}
                className="flex-1 py-3.5 bg-[#0071e3] text-white rounded-full font-bold text-xs sm:text-sm hover:bg-[#005cbb] transition-colors shadow-sm"
              >
                بازگشت به ویترین محصولات
              </button>
              <button
                onClick={() => setActivePage('support')}
                className="py-3.5 px-6 bg-[#f0eff5] dark:bg-[#25262c] text-gray-800 dark:text-gray-200 rounded-full font-semibold text-xs hover:bg-gray-200 transition-colors"
              >
                پیگیری آنلاین مرسوله
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Step 1 & 2 Main Body (8 Cols) */}
            <div className="lg:col-span-8 flex flex-col gap-5">
              {step === 1 && (
                <>
                  {/* Free Shipping Status Notification Bar */}
                  <div className="bg-[#f0eff5] dark:bg-[#1a1b1f] rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xs border border-black/[0.02] dark:border-white/[0.04]">
                    <div className="flex items-center gap-3.5 text-right w-full sm:w-auto">
                      <div className="w-10 h-10 rounded-xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center flex-shrink-0">
                        <span className="material-symbols-outlined text-xl">local_shipping</span>
                      </div>
                      <div>
                        <p className="font-bold text-xs sm:text-sm text-gray-900 dark:text-white">
                          ارسال فوق‌سریع و ایمن رایگان فعال شد
                        </p>
                        <p className="text-[11px] text-gray-500 dark:text-gray-400 mt-0.5">
                          سفارش شما فراتر از سقف خرید ۱,۰۰۰,۰۰۰ تومان قرار دارد و بدون هزینه پست ارسال می‌گردد.
                        </p>
                      </div>
                    </div>
                    <div className="w-full sm:w-44 bg-gray-200 dark:bg-gray-700 rounded-full h-2 overflow-hidden flex-shrink-0">
                      <div className="bg-[#0071e3] h-full rounded-full w-full"></div>
                    </div>
                  </div>

                  {/* Empty Cart State */}
                  {cart.length === 0 ? (
                    <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-12 text-center shadow-xs border border-gray-100 dark:border-gray-800 space-y-4">
                      <div className="w-16 h-16 rounded-full bg-gray-100 dark:bg-gray-800 text-gray-400 mx-auto flex items-center justify-center">
                        <span className="material-symbols-outlined text-4xl">shopping_cart_off</span>
                      </div>
                      <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                        سبد خرید شما اکنون خالی است
                      </h3>
                      <p className="text-xs text-gray-500 dark:text-gray-400 max-w-sm mx-auto">
                        هیچ کالایی در سبد موجود نیست. برای مشاهده جدیدترین اکسسوری‌های تیتانیومی و شارژرهای هوشمند به فروشگاه بازگردید.
                      </p>
                      <button
                        onClick={() => setActivePage('store')}
                        className="inline-flex items-center gap-2 bg-[#0071e3] text-white px-6 py-2.5 rounded-full text-xs font-bold hover:bg-[#005cbb] transition-colors shadow-xs"
                      >
                        <span>مشاهده ویترین محصولات</span>
                        <span className="material-symbols-outlined text-base">arrow_back</span>
                      </button>
                    </div>
                  ) : (
                    /* Cart Item Cards List */
                    cart.map(item => (
                      <div
                        key={item.id}
                        className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-4 sm:p-6 shadow-xs border border-black/[0.03] dark:border-white/[0.05] transition-all relative text-right"
                      >
                        <div className="flex flex-col sm:flex-row gap-4 items-center">
                          {/* Thumbnail */}
                          <div
                            onClick={() => openProductDetail(item.product.id)}
                            className="w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-[#faf8fe] dark:bg-[#22242a] flex-shrink-0 flex items-center justify-center p-2 relative cursor-pointer"
                          >
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              className="w-full h-full object-contain"
                            />
                            {item.product.badge && (
                              <span className="absolute top-2 right-2 bg-white/90 dark:bg-black/60 backdrop-blur-md px-1.5 py-0.5 rounded text-[10px] text-gray-600 dark:text-gray-300">
                                {item.product.badge}
                              </span>
                            )}
                          </div>

                          {/* Details */}
                          <div className="flex-1 min-w-0 flex flex-col justify-between gap-3 w-full">
                            <div className="flex items-start justify-between gap-2">
                              <div>
                                <span className="text-[10px] text-gray-400">{item.product.categoryLabel}</span>
                                <h3
                                  onClick={() => openProductDetail(item.product.id)}
                                  className="text-sm sm:text-base font-bold text-gray-900 dark:text-white hover:text-[#0071e3] transition-colors cursor-pointer truncate"
                                >
                                  {item.product.name}
                                </h3>
                              </div>
                              <button
                                onClick={() => removeFromCart(item.id)}
                                className="text-gray-400 hover:text-red-500 transition-colors p-1"
                                title="حذف کالا"
                              >
                                <span className="material-symbols-outlined text-xl">delete_outline</span>
                              </button>
                            </div>

                            {/* Color & Warranty specs */}
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-[#f4f3f8] dark:bg-[#22242a] rounded-full text-xs text-gray-700 dark:text-gray-300">
                                <span
                                  className="w-2.5 h-2.5 rounded-full"
                                  style={{ backgroundColor: item.selectedColor.hex }}
                                />
                                {item.selectedColor.name}
                              </span>

                              {item.selectedCapacity && (
                                <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#f4f3f8] dark:bg-[#22242a] rounded-full text-xs text-gray-700 dark:text-gray-300">
                                  {item.selectedCapacity.label}
                                </span>
                              )}

                              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#f4f3f8] dark:bg-[#22242a] rounded-full text-xs text-gray-700 dark:text-gray-300">
                                <span className="material-symbols-outlined text-xs text-[#0071e3]">
                                  verified_user
                                </span>
                                {item.product.warrantyType}
                              </span>
                            </div>

                            {/* Controls and line total */}
                            <div className="flex items-center justify-between pt-1">
                              {/* Quantity Counter */}
                              <div className="flex items-center bg-[#f4f3f8] dark:bg-[#22242a] rounded-full p-1 gap-1">
                                <button
                                  type="button"
                                  onClick={() => updateCartQuantity(item.id, 1)}
                                  className="w-7 h-7 rounded-full bg-white dark:bg-[#1a1b1f] hover:bg-[#0071e3] hover:text-white text-gray-800 dark:text-gray-200 flex items-center justify-center transition-all shadow-xs cursor-pointer"
                                >
                                  <span className="material-symbols-outlined text-sm">add</span>
                                </button>
                                <span className="font-bold text-xs sm:text-sm text-gray-900 dark:text-white w-7 text-center font-mono">
                                  {toPersianDigits(item.quantity)}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => updateCartQuantity(item.id, -1)}
                                  className="w-7 h-7 rounded-full bg-white dark:bg-[#1a1b1f] hover:bg-[#0071e3] hover:text-white text-gray-800 dark:text-gray-200 flex items-center justify-center transition-all shadow-xs cursor-pointer"
                                >
                                  <span className="material-symbols-outlined text-sm">remove</span>
                                </button>
                              </div>

                              {/* Price */}
                              <div className="text-left flex flex-col items-end">
                                <span className="text-[11px] text-gray-400">
                                  واحد: {formatPersianPrice(item.unitPrice)} تومان
                                </span>
                                <div className="flex items-baseline gap-1">
                                  <span className="text-base sm:text-lg font-bold text-gray-900 dark:text-white">
                                    {formatPersianPrice(item.unitPrice * item.quantity)}
                                  </span>
                                  <span className="text-xs text-gray-500">تومان</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Save for Later footer link */}
                        <div className="mt-3 pt-3 border-t border-gray-100 dark:border-gray-800 flex justify-between items-center text-xs text-gray-400">
                          <button
                            type="button"
                            onClick={() => saveForLater(item.id)}
                            className="hover:text-[#0071e3] flex items-center gap-1 transition-colors cursor-pointer"
                          >
                            <span className="material-symbols-outlined text-base">bookmark_border</span>
                            <span>انتقال به لیست خرید بعدی</span>
                          </button>
                          <span className="font-mono text-[11px]">کد انبار: {item.product.code}</span>
                        </div>
                      </div>
                    ))
                  )}

                  {/* Saved for Later Module */}
                  {savedForLater.length > 0 && (
                    <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 shadow-xs border border-black/[0.03] dark:border-white/[0.05] mt-2 text-right">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <span className="material-symbols-outlined text-[#0071e3] text-xl">bookmark_add</span>
                          <h4 className="font-bold text-sm text-gray-900 dark:text-white">
                            کالاهای ذخیره شده برای آینده ({toPersianDigits(savedForLater.length)} کالا)
                          </h4>
                        </div>
                        <span className="text-[11px] text-gray-400">قابل انتقال سریع به سبد</span>
                      </div>

                      <div className="space-y-3">
                        {savedForLater.map(savedItem => (
                          <div
                            key={savedItem.id}
                            className="flex flex-col sm:flex-row items-center justify-between gap-4 bg-[#f8f7fc] dark:bg-[#22242a] p-3 rounded-2xl border border-black/[0.02] dark:border-white/[0.04]"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-14 h-14 rounded-xl bg-white dark:bg-[#1a1b1f] p-1 flex-shrink-0 flex items-center justify-center">
                                <img
                                  src={savedItem.product.image}
                                  alt={savedItem.product.name}
                                  className="w-full h-full object-contain"
                                />
                              </div>
                              <div className="text-right">
                                <h5 className="font-bold text-xs sm:text-sm text-gray-900 dark:text-white">
                                  {savedItem.product.name}
                                </h5>
                                <p className="text-[11px] text-gray-500">
                                  قیمت روز: {formatPersianPrice(savedItem.unitPrice)} تومان
                                </p>
                              </div>
                            </div>

                            <button
                              onClick={() => moveToCartFromSaved(savedItem.id)}
                              className="w-full sm:w-auto px-4 py-2 rounded-full bg-white dark:bg-[#1a1b1f] hover:bg-[#0071e3] hover:text-white text-gray-800 dark:text-gray-200 text-xs font-semibold transition-all flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                            >
                              <span className="material-symbols-outlined text-sm">add_shopping_cart</span>
                              <span>انتقال مجدد به سبد</span>
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* Step 2 Form (Address & Slot Selection) */}
              {step === 2 && (
                <form
                  onSubmit={handleFinalPayment}
                  className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 sm:p-8 shadow-xs border border-gray-100 dark:border-gray-800 space-y-6 text-right animate-in fade-in duration-300"
                >
                  <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
                    <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                      <span className="material-symbols-outlined text-[#0071e3]">pin_drop</span>
                      مشخصات تحویل‌گیرنده و آدرس
                    </h3>
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="text-xs text-[#0071e3] hover:underline"
                    >
                      ویرایش اقلام سبد
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        نام و نام خانوادگی *
                      </label>
                      <input
                        type="text"
                        required
                        value={recipientName}
                        onChange={e => setRecipientName(e.target.value)}
                        className="w-full text-xs p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3]"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        شماره همراه *
                      </label>
                      <input
                        type="tel"
                        required
                        value={recipientPhone}
                        onChange={e => setRecipientPhone(e.target.value)}
                        className="w-full text-xs p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3] text-left font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        استان / شهر *
                      </label>
                      <input
                        type="text"
                        required
                        value={recipientCity}
                        onChange={e => setRecipientCity(e.target.value)}
                        className="w-full text-xs p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3]"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                        نشانی پستی دقیق *
                      </label>
                      <input
                        type="text"
                        required
                        value={recipientAddress}
                        onChange={e => setRecipientAddress(e.target.value)}
                        className="w-full text-xs p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3]"
                      />
                    </div>
                  </div>

                  {/* Delivery Slot Selection */}
                  <div className="space-y-2 pt-2">
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                      بازه زمانی تحویل مرسوله:
                    </label>
                    <div className="space-y-2">
                      {[
                        'امروز بعدازظهر (ساعت ۱۶ تا ۲۰) - ارسال اختصاصی تهران',
                        'فردا صبح (ساعت ۹ تا ۱۳) - ارسال سریع',
                        'پست پیشتاز بیمه‌شده (تحویل ۲۴ تا ۴۸ ساعته شهرستان)',
                      ].map(option => (
                        <label
                          key={option}
                          className={`flex items-center gap-3 p-3 rounded-2xl border text-xs cursor-pointer transition-all ${
                            deliverySlot === option
                              ? 'border-[#0071e3] bg-[#0071e3]/5 text-[#0071e3] font-bold'
                              : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                          }`}
                        >
                          <input
                            type="radio"
                            name="deliverySlot"
                            checked={deliverySlot === option}
                            onChange={() => setDeliverySlot(option)}
                            className="accent-[#0071e3]"
                          />
                          <span>{option}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Payment Type Selection */}
                  <div className="space-y-2 pt-2">
                    <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                      نحوه پرداخت وجه:
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        type="button"
                        onClick={() => setPaymentType('shetab')}
                        className={`p-3.5 rounded-2xl border text-xs flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer ${
                          paymentType === 'shetab'
                            ? 'border-[#0071e3] bg-[#0071e3]/10 text-[#0071e3] font-bold shadow-xs'
                            : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                        }`}
                      >
                        <span className="material-symbols-outlined text-xl">credit_card</span>
                        <span>درگاه مستقیم شتاب</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentType('installment')}
                        className={`p-3.5 rounded-2xl border text-xs flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer ${
                          paymentType === 'installment'
                            ? 'border-[#0071e3] bg-[#0071e3]/10 text-[#0071e3] font-bold shadow-xs'
                            : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                        }`}
                      >
                        <span className="material-symbols-outlined text-xl">splitscreen</span>
                        <span>اقساط ۴ ماهه اسنپ‌پی</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setPaymentType('vip')}
                        className={`p-3.5 rounded-2xl border text-xs flex flex-col items-center justify-center text-center gap-1.5 transition-all cursor-pointer ${
                          paymentType === 'vip'
                            ? 'border-[#0071e3] bg-[#0071e3]/10 text-[#0071e3] font-bold shadow-xs'
                            : 'border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300'
                        }`}
                      >
                        <span className="material-symbols-outlined text-xl">account_balance_wallet</span>
                        <span>کیف پول باشگاه VIP</span>
                      </button>
                    </div>
                  </div>

                  <div className="pt-4 flex gap-3">
                    <button
                      type="submit"
                      className="flex-1 py-3.5 bg-[#0071e3] hover:bg-[#005cbb] text-white rounded-full font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <span>تایید و پرداخت {formatPersianPrice(finalPayable)} تومان</span>
                      <span className="material-symbols-outlined text-lg">lock</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="py-3.5 px-6 rounded-full bg-[#f0eff5] dark:bg-[#25262c] text-gray-700 dark:text-gray-300 text-xs font-semibold hover:bg-gray-200"
                    >
                      مرحله قبل
                    </button>
                  </div>
                </form>
              )}
            </div>

            {/* Sticky Order Summary Sidebar (4 Cols) */}
            <div className="lg:col-span-4 sticky top-28 space-y-4 text-right">
              <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 shadow-sm border border-black/[0.04] dark:border-white/[0.06] space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-base text-gray-900 dark:text-white">خلاصه پیش‌فاکتور</h3>
                  <span className="bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] text-xs font-bold px-2.5 py-0.5 rounded-full">
                    {toPersianDigits(cartTotalCount)} قلم کالا
                  </span>
                </div>

                {/* Price Ledger */}
                <div className="space-y-2.5 text-xs text-gray-600 dark:text-gray-300 pt-1">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-800 dark:text-gray-200">جمع کل اقلام (ناخالص)</span>
                    <div className="flex items-baseline gap-1 font-bold text-gray-900 dark:text-white">
                      <span>{formatPersianPrice(cartSubtotal)}</span>
                      <span className="text-[10px] text-gray-400">تومان</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400">
                    <span className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">local_offer</span>
                      تخفیف نقدی فروش ویژه
                    </span>
                    <div className="flex items-baseline gap-1 font-bold">
                      <span>{cart.length > 0 ? '۳۵۰,۰۰۰-' : '۰'}</span>
                      <span className="text-[10px]">تومان</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-gray-500">
                    <span className="flex items-center gap-1">
                      <span className="material-symbols-outlined text-sm">security</span>
                      بیمه کامل سلامت مرسوله
                    </span>
                    <span className="text-gray-800 dark:text-gray-200 font-semibold">رایگان (تکنونت)</span>
                  </div>

                  <div className="flex items-center justify-between">
                    <span>هزینه بسته‌بندی ضدضربه و پست</span>
                    <span className="text-[#0071e3] dark:text-[#abc7ff] font-bold">رایگان</span>
                  </div>

                  {voucherDiscount > 0 && (
                    <div className="flex items-center justify-between text-[#0071e3] dark:text-[#abc7ff] font-bold">
                      <span>کوپن تخفیف اعمال شده ({appliedCoupon})</span>
                      <div className="flex items-baseline gap-1">
                        <span>{formatPersianPrice(voucherDiscount)}-</span>
                        <span className="text-[10px]">تومان</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="h-px bg-gray-100 dark:bg-gray-800 w-full"></div>

                {/* Total Payable Block */}
                <div className="bg-[#f8f7fc] dark:bg-[#22242a] p-4 rounded-2xl flex items-center justify-between border border-black/[0.02] dark:border-white/[0.04]">
                  <div>
                    <span className="text-[11px] text-gray-400 block">مبلغ نهایی قابل پرداخت</span>
                    <span className="text-[10px] text-gray-500">شامل مالیات و عوارض قانونی</span>
                  </div>
                  <div className="text-left flex items-baseline gap-1">
                    <span className="text-xl sm:text-2xl font-extrabold text-[#0071e3] dark:text-[#abc7ff] tracking-tight">
                      {formatPersianPrice(finalPayable)}
                    </span>
                    <span className="text-xs font-bold text-gray-900 dark:text-white">تومان</span>
                  </div>
                </div>

                {/* Coupon Input */}
                <div className="pt-1">
                  <div className="flex items-center gap-1.5 bg-[#f4f3f8] dark:bg-[#23242a] p-1.5 rounded-xl border border-transparent focus-within:border-[#0071e3]">
                    <span className="material-symbols-outlined text-gray-400 pr-2 text-base">
                      confirmation_number
                    </span>
                    <input
                      type="text"
                      value={couponInput}
                      onChange={e => setCouponInput(e.target.value)}
                      placeholder="کد تخفیف (مثلا: TECNO500)"
                      className="flex-1 bg-transparent px-1 py-1 text-xs text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none text-right font-mono"
                    />
                    <button
                      type="button"
                      onClick={handleApplyCoupon}
                      className="bg-white dark:bg-[#1a1b1f] hover:bg-[#0071e3] hover:text-white text-gray-800 dark:text-gray-200 text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors shadow-xs cursor-pointer"
                    >
                      اعمال
                    </button>
                  </div>
                  {couponError && <p className="text-[10px] text-red-500 mt-1 px-1">{couponError}</p>}
                </div>

                {/* Checkout CTA */}
                {step === 1 && (
                  <div className="space-y-2 pt-1">
                    <button
                      type="button"
                      onClick={handleProceedToStep2}
                      className="w-full bg-[#0071e3] hover:bg-[#005cbb] text-white text-sm py-3.5 px-6 rounded-full font-bold flex items-center justify-center gap-2 transition-all shadow-md transform hover:-translate-y-0.5 active:translate-y-0 cursor-pointer"
                    >
                      <span>تایید اطلاعات و ادامه خرید</span>
                      <span className="material-symbols-outlined text-lg">arrow_back</span>
                    </button>
                    <p className="text-[10px] text-center text-gray-400">
                      رزرو موجودی کالاها برای ۱۵ دقیقه معتبر است
                    </p>
                  </div>
                )}

                {/* Payment Gateway Badges */}
                <div className="pt-2 space-y-2">
                  <span className="text-[10px] text-gray-400 block text-center">
                    روش‌های پرداخت پشتیبانی‌شده
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="bg-[#f8f7fc] dark:bg-[#22242a] p-2 rounded-xl flex flex-col items-center justify-center text-center">
                      <span className="material-symbols-outlined text-[#0071e3] text-base mb-0.5">
                        credit_card
                      </span>
                      <span className="text-[10px] text-gray-700 dark:text-gray-300 font-medium">
                        شتاب مستقیم
                      </span>
                    </div>

                    <div className="bg-[#f8f7fc] dark:bg-[#22242a] p-2 rounded-xl flex flex-col items-center justify-center text-center">
                      <span className="material-symbols-outlined text-[#0071e3] text-base mb-0.5">
                        splitscreen
                      </span>
                      <span className="text-[10px] text-gray-700 dark:text-gray-300 font-medium">
                        اقساط ۴ ماهه
                      </span>
                    </div>

                    <div className="bg-[#f8f7fc] dark:bg-[#22242a] p-2 rounded-xl flex flex-col items-center justify-center text-center">
                      <span className="material-symbols-outlined text-amber-500 text-base mb-0.5">
                        account_balance_wallet
                      </span>
                      <span className="text-[10px] text-gray-700 dark:text-gray-300 font-medium">
                        کیف پول VIP
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Encryption Trust Badge */}
              <div className="bg-[#f0eff5] dark:bg-[#1a1b1f] rounded-2xl p-4 flex items-center gap-3 shadow-xs border border-black/[0.02] dark:border-white/[0.04]">
                <div className="w-9 h-9 rounded-full bg-white dark:bg-[#25262c] text-[#0071e3] flex items-center justify-center shadow-xs flex-shrink-0">
                  <span className="material-symbols-outlined text-lg">lock</span>
                </div>
                <div>
                  <h5 className="font-bold text-xs text-gray-900 dark:text-white">رمزنگاری سرتاسری ۲۵۶ بیتی</h5>
                  <p className="text-[11px] text-gray-500 dark:text-gray-400">
                    اتصال امن به درگاه رسمی شاپرک بانک مرکزی با تاییدیه دو مرحله‌ای
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* Brand Guarantees Ribbon */}
      <section className="w-full bg-white dark:bg-[#16171b] py-12 border-t border-black/[0.04] dark:border-white/[0.06] text-right">
        <div className="max-w-[1380px] mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="flex items-start gap-4 p-2">
              <div className="w-12 h-12 rounded-2xl bg-[#f0eff5] dark:bg-[#202126] text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center flex-shrink-0">
                <span className="material-symbols-outlined text-2xl font-bold">published_with_changes</span>
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">۷ روز ضمانت بازگشت</h4>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 leading-relaxed">
                  امکان عودت وجه یا تعویض آنی کالا در صورت عدم رضایت یا عدم تطابق فیزیکی کالا.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-2">
              <div className="w-12 h-12 rounded-2xl bg-[#f0eff5] dark:bg-[#202126] text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center flex-shrink-0">
                <span className="material-symbols-outlined text-2xl font-bold">verified</span>
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">اصالت قطعی متریال</h4>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 leading-relaxed">
                  تضمین استفاده از تیتانیوم گرید ۵، الیاف کربن ژاپنی و کابل‌های دارای مجوز استاندارد جهانی.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-2">
              <div className="w-12 h-12 rounded-2xl bg-[#f0eff5] dark:bg-[#202126] text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center flex-shrink-0">
                <span className="material-symbols-outlined text-2xl font-bold">headset_mic</span>
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">مشاوره تخصصی ۲۴/۷</h4>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 leading-relaxed">
                  پاسخگویی مهندسان سخت‌افزار برای انتخاب بهترین پروتکل و لوازم هماهنگ با تجهیزات شما.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-2">
              <div className="w-12 h-12 rounded-2xl bg-[#f0eff5] dark:bg-[#202126] text-[#0071e3] dark:text-[#abc7ff] flex items-center justify-center flex-shrink-0">
                <span className="material-symbols-outlined text-2xl font-bold">package_2</span>
              </div>
              <div>
                <h4 className="font-bold text-sm text-gray-900 dark:text-white">بسته‌بندی اکولوژیک</h4>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 leading-relaxed">
                  بسته‌بندی ضربه‌گیر کامپوزیت بدون پلاستیک، منطبق با استانداردهای حفاظت از محیط زیست.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sticky Mobile Checkout Bar */}
      {step === 1 && cart.length > 0 && (
        <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#1a1b1f]/95 backdrop-blur-xl p-4 border-t border-black/[0.05] dark:border-white/[0.08] shadow-2xl flex items-center justify-between gap-4">
          <div className="text-right">
            <span className="text-[10px] text-gray-400 block">مبلغ نهایی قابل پرداخت</span>
            <div className="flex items-baseline gap-1">
              <span className="text-lg font-extrabold text-[#0071e3] dark:text-[#abc7ff]">
                {formatPersianPrice(finalPayable)}
              </span>
              <span className="text-[11px] font-bold text-gray-900 dark:text-white">تومان</span>
            </div>
          </div>
          <button
            onClick={handleProceedToStep2}
            className="bg-[#0071e3] text-white text-xs font-bold px-6 py-3 rounded-full flex items-center gap-1.5 shadow-md"
          >
            <span>تکمیل سفارش</span>
            <span className="material-symbols-outlined text-base">arrow_back</span>
          </button>
        </div>
      )}
    </div>
  );
};
