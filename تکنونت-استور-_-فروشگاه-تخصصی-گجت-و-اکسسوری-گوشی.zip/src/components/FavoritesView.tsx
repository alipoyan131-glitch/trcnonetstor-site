import React from 'react';
import { useStore } from '../context/StoreContext';
import { PRODUCTS } from '../data/products';
import { formatPersianPrice, toPersianDigits } from '../utils/formatters';

export const FavoritesView: React.FC = () => {
  const { favorites, toggleFavorite, openProductDetail, addToCart, setActivePage } = useStore();

  const favoriteProducts = PRODUCTS.filter(p => favorites.includes(p.id));

  return (
    <div className="w-full pb-20 pt-6">
      <div className="max-w-[1380px] mx-auto px-4 sm:px-6">
        {/* Banner */}
        <div className="text-right mb-8 space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs font-bold">
            <span className="material-symbols-outlined text-sm filled">favorite</span>
            <span>لیست منتخب و نشان‌شده</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900 dark:text-white">
            کالاهای مورد علاقه شما ({toPersianDigits(favoriteProducts.length)})
          </h1>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400">
            گجت‌های نشان‌شده برای خرید آسان و مقایسه سریع‌تر مشخصات
          </p>
        </div>

        {favoriteProducts.length === 0 ? (
          <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-12 text-center shadow-xs border border-gray-100 dark:border-gray-800 space-y-4 max-w-lg mx-auto">
            <div className="w-16 h-16 rounded-full bg-rose-50 dark:bg-rose-950/40 text-rose-500 mx-auto flex items-center justify-center">
              <span className="material-symbols-outlined text-4xl">favorite_border</span>
            </div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white">
              هنوز کالایی به علاقه‌مندی‌ها اضافه نشده است
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              با کلیک روی آیکون قلب در کنار هر محصول، می‌توانید آن را به این بخش اضافه فرمایید.
            </p>
            <button
              onClick={() => setActivePage('store')}
              className="inline-flex items-center gap-2 bg-[#0071e3] text-white px-6 py-2.5 rounded-full text-xs font-bold hover:bg-[#005cbb] transition-colors shadow-xs"
            >
              <span>مشاهده فروشگاه</span>
              <span className="material-symbols-outlined text-base">arrow_back</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {favoriteProducts.map(product => (
              <div
                key={product.id}
                className="group bg-white dark:bg-[#1a1b1f] rounded-3xl p-4 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between relative border border-black/[0.03] dark:border-white/[0.04]"
              >
                {/* Remove from wishlist button */}
                <button
                  onClick={() => toggleFavorite(product.id)}
                  aria-label="حذف از نشان‌شده‌ها"
                  className="absolute top-4 left-4 z-10 w-9 h-9 rounded-full bg-white/80 dark:bg-black/50 backdrop-blur-md flex items-center justify-center text-rose-500 hover:scale-110 transition-transform shadow-xs"
                >
                  <span className="material-symbols-outlined text-lg filled">favorite</span>
                </button>

                <div
                  onClick={() => openProductDetail(product.id)}
                  className="w-full aspect-square rounded-2xl bg-[#faf8fe] dark:bg-[#22242a] mb-4 overflow-hidden relative flex items-center justify-center p-4 cursor-pointer"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-500"
                  />
                </div>

                <div className="space-y-1.5 text-right">
                  <span className="text-[11px] text-gray-400 font-semibold">{product.brand}</span>
                  <h3
                    onClick={() => openProductDetail(product.id)}
                    className="font-bold text-sm text-gray-900 dark:text-white group-hover:text-[#0071e3] transition-colors line-clamp-1 cursor-pointer"
                  >
                    {product.name}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-1">
                    {product.shortSpecs}
                  </p>
                </div>

                <div className="pt-4 mt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
                  <div className="text-right">
                    <span className="text-sm font-bold text-gray-900 dark:text-white">
                      {formatPersianPrice(product.price)}
                    </span>
                    <span className="text-[11px] text-gray-500 mr-1">تومان</span>
                  </div>

                  <button
                    onClick={() => addToCart(product)}
                    className="w-10 h-10 rounded-full bg-[#0071e3] text-white flex items-center justify-center hover:bg-[#005cbb] active:scale-95 transition-all shadow-sm"
                    title="افزودن به سبد خرید"
                  >
                    <span className="material-symbols-outlined text-lg">add_shopping_cart</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
