import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { formatPersianPrice } from '../utils/formatters';

export const QuickBuyModal: React.FC = () => {
  const { isQuickBuyOpen, setIsQuickBuyOpen, quickBuyProduct, showToast, clearCart, setActivePage } = useStore();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [slot, setSlot] = useState('امروز بعدازظهر (ساعت ۱۶ تا ۲۰)');
  const [paymentMethod, setPaymentMethod] = useState<'shetab' | 'snapp'>('shetab');
  const [isSuccess, setIsSuccess] = useState(false);
  const [trackingCode, setTrackingCode] = useState('');

  if (!isQuickBuyOpen || !quickBuyProduct) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || !address.trim()) {
      showToast('لطفاً تمامی فیلدهای الزامی آدرس را تکمیل فرمایید.');
      return;
    }

    const code = 'TCN-' + Math.floor(100000 + Math.random() * 900000);
    setTrackingCode(code);
    setIsSuccess(true);
    showToast('سفارش آنی شما با موفقیت ثبت گردید.');
  };

  const handleFinish = () => {
    setIsSuccess(false);
    setIsQuickBuyOpen(false);
    setActivePage('home');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div
        className="w-full max-w-lg bg-white dark:bg-[#1a1b1f] rounded-3xl shadow-2xl overflow-hidden border border-gray-100 dark:border-gray-800 animate-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        {isSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 mx-auto flex items-center justify-center">
              <span className="material-symbols-outlined text-4xl font-bold">check_circle</span>
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white">سفارش با موفقیت ثبت گردید!</h3>
            <p className="text-xs text-gray-600 dark:text-gray-300">
              کالای شما برای تحویل سریع در بازه «{slot}» بسته‌بندی و ارسال خواهد شد.
            </p>
            <div className="p-3 bg-gray-50 dark:bg-[#25262c] rounded-2xl font-mono text-sm text-[#0071e3] dark:text-[#abc7ff] font-bold">
              کد پیگیری رسمی: {trackingCode}
            </div>
            <button
              onClick={handleFinish}
              className="w-full py-3 bg-[#0071e3] text-white rounded-full font-semibold text-sm hover:bg-[#005cbb] transition-colors shadow-md"
            >
              بازگشت به فروشگاه
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
              <div className="flex items-center gap-2">
                <span className="material-symbols-outlined text-[#0071e3] text-2xl">flash_on</span>
                <h3 className="text-base font-bold text-gray-900 dark:text-white">خرید آنی با یک کلیک</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsQuickBuyOpen(false)}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center text-gray-500 hover:text-gray-900 dark:hover:text-white"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>

            {/* Product summary card */}
            <div className="flex items-center gap-3 p-3 bg-gray-50 dark:bg-[#25262c] rounded-2xl">
              <img src={quickBuyProduct.image} alt={quickBuyProduct.name} className="w-14 h-14 object-contain rounded-xl bg-white dark:bg-gray-800 p-1" />
              <div className="flex-1 min-w-0">
                <h4 className="text-xs font-bold text-gray-900 dark:text-white truncate">{quickBuyProduct.name}</h4>
                <div className="flex items-center justify-between mt-1 text-xs">
                  <span className="text-gray-400">{quickBuyProduct.brand}</span>
                  <span className="font-bold text-[#0071e3] dark:text-[#abc7ff]">
                    {formatPersianPrice(quickBuyProduct.price)} تومان
                  </span>
                </div>
              </div>
            </div>

            {/* Recipient Form */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  نام و نام خانوادگی تحویل‌گیرنده *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="مثال: علی پویا"
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  شماره موبایل جهت هماهنگی پیک *
                </label>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3] text-left font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  آدرس دقیق پستی *
                </label>
                <textarea
                  rows={2}
                  required
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="شهر، خیابان اصلی، کوچه، پلاک، واحد"
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-transparent text-gray-900 dark:text-white focus:outline-none focus:border-[#0071e3]"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  بازه زمانی تحویل سفارش
                </label>
                <select
                  value={slot}
                  onChange={e => setSlot(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-[#1a1b1f] text-gray-900 dark:text-white focus:outline-none"
                >
                  <option value="امروز بعدازظهر (ساعت ۱۶ تا ۲۰)">امروز بعدازظهر (ساعت ۱۶ تا ۲۰) - اکسپرس فوری</option>
                  <option value="فردا صبح (ساعت ۹ تا ۱۳)">فردا صبح (ساعت ۹ تا ۱۳)</option>
                  <option value="ارسال پستی بیمه‌شده سراسر کشور">ارسال پستی بیمه‌شده سراسر کشور (۲۴ تا ۴۸ ساعت)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">
                  روش پرداخت
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('shetab')}
                    className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'shetab'
                        ? 'border-[#0071e3] bg-[#0071e3]/10 text-[#0071e3] font-bold'
                        : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400'
                    }`}
                  >
                    <span className="material-symbols-outlined text-base">credit_card</span>
                    درگاه شتاب مستقیم
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('snapp')}
                    className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'snapp'
                        ? 'border-[#0071e3] bg-[#0071e3]/10 text-[#0071e3] font-bold'
                        : 'border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-400'
                    }`}
                  >
                    <span className="material-symbols-outlined text-base">splitscreen</span>
                    اقساطی ۴ ماهه
                  </button>
                </div>
              </div>
            </div>

            {/* Submit */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3 bg-[#0071e3] hover:bg-[#005cbb] text-white rounded-full font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                <span>تکمیل نهایی و پرداخت</span>
                <span className="material-symbols-outlined text-lg">arrow_left_alt</span>
              </button>
              <p className="text-[10px] text-center text-gray-400 mt-2">
                با گارانتی اصالت کالا و ۷ روز مهلت تست اختصاصی تکنونت
              </p>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
