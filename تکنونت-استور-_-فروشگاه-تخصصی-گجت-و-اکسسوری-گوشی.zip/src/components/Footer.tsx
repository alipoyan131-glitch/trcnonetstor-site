import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';

export const Footer: React.FC = () => {
  const { setActivePage, setCategoryFilter, showToast } = useStore();
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim().includes('@')) {
      showToast('ایمیل شما با موفقیت در خبرنامه اعضای VIP تکنونت ثبت شد.');
      setEmail('');
    } else {
      showToast('لطفاً یک آدرس ایمیل معتبر وارد فرمایید.');
    }
  };

  return (
    <footer className="w-full bg-white dark:bg-[#16171b] border-t border-black/[0.04] dark:border-white/[0.06] shadow-[0_-1px_12px_rgba(0,0,0,0.02)] mt-16 transition-colors duration-200">
      <div className="max-w-[1380px] mx-auto px-4 sm:px-6 pt-12 pb-8">
        {/* Top 3 Trust Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pb-12 mb-12 border-b border-gray-100 dark:border-gray-800">
          <div className="flex items-center gap-4 p-4 bg-[#f8f7fc] dark:bg-[#1f2025] rounded-2xl">
            <div className="w-12 h-12 rounded-2xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 flex items-center justify-center text-[#0071e3] dark:text-[#abc7ff] flex-shrink-0">
              <span className="material-symbols-outlined text-2xl">verified</span>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white text-base">ضمانت اصالت ۱۰۰٪</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">تمامی لوازم جانبی اورجینال و با گواهی رسمی هستند.</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-4 bg-[#f8f7fc] dark:bg-[#1f2025] rounded-2xl">
            <div className="w-12 h-12 rounded-2xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 flex items-center justify-center text-[#0071e3] dark:text-[#abc7ff] flex-shrink-0">
              <span className="material-symbols-outlined text-2xl">local_shipping</span>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white text-base">ارسال اکسپرس</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">تحویل سریع و بیمه‌شده در سراسر کشور با بسته‌بندی ایمن.</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-4 bg-[#f8f7fc] dark:bg-[#1f2025] rounded-2xl">
            <div className="w-12 h-12 rounded-2xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 flex items-center justify-center text-[#0071e3] dark:text-[#abc7ff] flex-shrink-0">
              <span className="material-symbols-outlined text-2xl">replay</span>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white text-base">۷ روز مهلت بازگشت</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">امکان تعویض یا بازگشت کالا بدون قید و شرط و استرداد وجه.</p>
            </div>
          </div>
        </div>

        {/* 4 Columns Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-12">
          {/* Col 1: About */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#005cbb] to-[#0071e3] text-white flex items-center justify-center shadow-sm">
                <span className="material-symbols-outlined text-xl font-bold">bolt</span>
              </div>
              <span className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">
                تکنونت استور
              </span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed max-w-sm">
              فروشگاه تخصصی لوازم جانبی فوق‌پیشرفته و کالاهای صوتی-تصویری تراز اول. پیوند معماری مینیمال، متریال آلیاژ تیتانیوم گرید هوافضا و اصالت بی‌بدیل تجربه کاربری.
            </p>
            <div className="flex items-center gap-3 pt-2 text-gray-400 dark:text-gray-500">
              <span className="text-xs">تایید شده توسط استاندارد Qi2 و اتحادیه الکترونیک</span>
            </div>
          </div>

          {/* Col 2: Categories */}
          <div className="lg:col-span-2 space-y-3">
            <h5 className="text-sm font-bold text-gray-900 dark:text-white">دسته‌بندی‌ها</h5>
            <ul className="space-y-2 text-xs text-gray-600 dark:text-gray-400">
              <li>
                <button
                  onClick={() => setCategoryFilter('cases')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  محافظ‌ها و قاب‌های تیتانیومی
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCategoryFilter('chargers')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  شارژرهای بی‌سیم MagSafe
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCategoryFilter('desktop')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  اکسسوری‌های هوشمند میز کار
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCategoryFilter('cables')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  کابل‌ها و مبدل‌های فیبر نوری
                </button>
              </li>
              <li>
                <button
                  onClick={() => setCategoryFilter('powerbanks')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  پاوربانک‌های فوق باریک Qi2
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Rules & VIP */}
          <div className="lg:col-span-2 space-y-3">
            <h5 className="text-sm font-bold text-gray-900 dark:text-white">خدمات و قوانین</h5>
            <ul className="space-y-2 text-xs text-gray-600 dark:text-gray-400">
              <li>
                <button
                  onClick={() => setActivePage('support')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  باشگاه مشتریان VIP
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActivePage('support')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  سیاست حفظ حریم خصوصی
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActivePage('support')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  شرایط استفاده از خدمات
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActivePage('support')}
                  className="hover:text-[#0071e3] dark:hover:text-[#abc7ff] transition-colors"
                >
                  ثبت گارانتی و استعلام سریال
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Newsletter */}
          <div className="lg:col-span-4 space-y-3">
            <h5 className="text-sm font-bold text-gray-900 dark:text-white">عضویت در خبرنامه محصولات ویژه</h5>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              از عرضه‌های محدود، تخفیف‌های فصلی و محصولات جدید کالکشن ۲۰۲۵ تکنونت استور زودتر از بقیه مطلع شوید.
            </p>
            <form onSubmit={handleSubscribe} className="flex items-center gap-1.5 bg-[#f0eff5] dark:bg-[#1f2025] p-1.5 rounded-full">
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="ایمیل خود را وارد کنید..."
                className="flex-1 bg-transparent px-3 py-1.5 text-xs text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none text-right"
              />
              <button
                type="submit"
                className="bg-[#0071e3] hover:bg-[#005cbb] text-white text-xs font-semibold px-4 py-2 rounded-full transition-colors whitespace-nowrap shadow-xs"
              >
                عضویت
              </button>
            </form>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-6 border-t border-gray-100 dark:border-gray-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400">
          <p>© ۲۰۲۵ تمامی حقوق مادی و معنوی متعلق به تکنونت استور است.</p>
          <p>طراحی و توسعه مهندسی شده بر پایه استانداردهای صنعتی و گجت‌های پرچمدار</p>
        </div>
      </div>
    </footer>
  );
};
