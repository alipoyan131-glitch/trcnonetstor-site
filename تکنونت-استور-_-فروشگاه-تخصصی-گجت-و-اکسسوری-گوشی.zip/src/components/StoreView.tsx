import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { PRODUCTS, CATEGORIES_META, BRANDS, COLOR_PALETTE } from '../data/products';
import { CategoryId } from '../types';
import { formatPersianPrice, toPersianDigits } from '../utils/formatters';

export const StoreView: React.FC = () => {
  const {
    filters,
    setFilters,
    resetFilters,
    openProductDetail,
    addToCart,
    toggleFavorite,
    isFavorite,
    setActivePage,
  } = useStore();

  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  // Toggle category in filters
  const handleCategoryToggle = (catId: CategoryId) => {
    setFilters(prev => {
      const exists = prev.categories.includes(catId);
      return {
        ...prev,
        categories: exists ? prev.categories.filter(c => c !== catId) : [...prev.categories, catId],
      };
    });
  };

  // Toggle brand in filters
  const handleBrandToggle = (brandName: string) => {
    setFilters(prev => {
      const exists = prev.brands.includes(brandName);
      return {
        ...prev,
        brands: exists ? prev.brands.filter(b => b !== brandName) : [...prev.brands, brandName],
      };
    });
  };

  // Filter and sort products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(p => {
      // Search query
      if (filters.searchQuery.trim()) {
        const q = filters.searchQuery.toLowerCase();
        const matches =
          p.name.toLowerCase().includes(q) ||
          p.brand.toLowerCase().includes(q) ||
          p.categoryLabel.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.shortSpecs.toLowerCase().includes(q);
        if (!matches) return false;
      }

      // Categories
      if (filters.categories.length > 0) {
        if (!filters.categories.includes(p.category)) return false;
      }

      // Brands
      if (filters.brands.length > 0) {
        if (!filters.brands.includes(p.brand)) return false;
      }

      // Price Range
      if (p.price < filters.priceRange[0] || p.price > filters.priceRange[1]) {
        return false;
      }

      // In stock
      if (filters.onlyInStock && !p.inStock) return false;

      // Express shipping
      if (filters.onlyExpress && !p.isExpress) return false;

      // Special discount
      if (filters.onlyDiscount && !p.hasDiscount) return false;

      return true;
    }).sort((a, b) => {
      if (filters.sortBy === 'price_asc') return a.price - b.price;
      if (filters.sortBy === 'price_desc') return b.price - a.price;
      if (filters.sortBy === 'popular') return b.rating - a.rating;
      if (filters.sortBy === 'bestseller') return b.reviewCount - a.reviewCount;
      return 0; // 'newest' default
    });
  }, [filters]);

  // Paginated subset
  const pageSize = 6;
  const totalPages = Math.ceil(filteredProducts.length / pageSize) || 1;
  const currentProducts = filteredProducts.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const activeFiltersCount =
    filters.categories.length +
    filters.brands.length +
    (filters.onlyInStock ? 1 : 0) +
    (filters.onlyExpress ? 1 : 0) +
    (filters.onlyDiscount ? 1 : 0);

  return (
    <div className="w-full pb-20">
      {/* Top Breadcrumb & Editorial Header Block */}
      <section className="max-w-[1380px] w-full mx-auto px-4 sm:px-6 mb-8 pt-4">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400 py-2 mb-4">
          <button
            onClick={() => setActivePage('home')}
            className="hover:text-[#0071e3] transition-colors"
          >
            خانه
          </button>
          <span className="material-symbols-outlined text-sm">chevron_left</span>
          <span className="text-gray-900 dark:text-white font-semibold">فروشگاه و همه محصولات</span>
        </div>

        {/* Editorial Header Banner */}
        <div className="relative overflow-hidden rounded-3xl bg-[#f0eff5] dark:bg-[#1b1c20] p-6 sm:p-10 shadow-xs border border-black/[0.03] dark:border-white/[0.05]">
          <div className="absolute -left-20 -top-24 w-96 h-96 bg-[#0071e3]/10 rounded-full blur-3xl pointer-events-none"></div>

          <div className="relative z-10 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div className="space-y-3 max-w-2xl text-right">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/80 dark:bg-white/10 text-[#0071e3] dark:text-[#abc7ff] text-xs font-bold shadow-xs">
                <span className="material-symbols-outlined text-xs">auto_awesome</span>
                <span>کالکشن جدید ۲۰۲۵ با مهندسی تیتانیوم</span>
              </div>
              <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 dark:text-white tracking-tight">
                فروشگاه و محصولات پریمیوم
              </h1>
              <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300 leading-relaxed">
                اکسسوری‌های تخصصی و گجت‌های معماری‌شده بر پایه ارگونومی، استانداردهای پرچمدار و خلوص مینیمال.
              </p>
            </div>

            <div className="flex items-center gap-4 bg-white/90 dark:bg-[#25262c]/90 backdrop-blur-md px-6 py-4 rounded-2xl shadow-xs self-start lg:self-auto border border-black/[0.03] dark:border-white/[0.06]">
              <div className="w-12 h-12 rounded-xl bg-[#0071e3]/10 dark:bg-[#0071e3]/20 flex items-center justify-center text-[#0071e3] dark:text-[#abc7ff]">
                <span className="material-symbols-outlined text-2xl">inventory_2</span>
              </div>
              <div>
                <div className="text-[11px] text-gray-500 dark:text-gray-400">موجودی کاتالوگ فعال</div>
                <div className="text-lg font-bold text-gray-900 dark:text-white">
                  ۳۴۸ <span className="text-xs font-normal text-gray-500">کالای اورجینال</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Catalog Area */}
      <section className="max-w-[1380px] w-full mx-auto px-4 sm:px-6">
        {/* Controls Bar: Search, Sorting, Mobile Filter Button */}
        <div className="bg-white dark:bg-[#1a1b1f] rounded-2xl p-4 shadow-xs border border-black/[0.03] dark:border-white/[0.05] mb-6 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          {/* Live Search */}
          <div className="relative flex-1 max-w-md">
            <span className="material-symbols-outlined absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 text-xl">
              search
            </span>
            <input
              type="text"
              value={filters.searchQuery}
              onChange={e => setFilters(prev => ({ ...prev, searchQuery: e.target.value }))}
              placeholder="جستجوی عنوان محصول، فناوری (MagSafe، فیبر نوری...)"
              className="w-full bg-[#f4f3f8] dark:bg-[#23242a] text-gray-900 dark:text-white text-xs sm:text-sm rounded-xl pr-11 pl-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-[#0071e3]/25 placeholder:text-gray-400 transition-all"
            />
          </div>

          {/* Quick Dropdown Sorting & Mobile Trigger */}
          <div className="flex items-center gap-3 justify-between md:justify-end">
            <div className="hidden xl:flex items-center gap-1.5 text-xs text-gray-500 dark:text-gray-400">
              <span>مرتب‌سازی:</span>
            </div>

            <div className="relative inline-block text-right min-w-[190px]">
              <select
                value={filters.sortBy}
                onChange={e => setFilters(prev => ({ ...prev, sortBy: e.target.value as any }))}
                className="w-full appearance-none bg-[#f4f3f8] dark:bg-[#23242a] text-gray-900 dark:text-white text-xs font-semibold rounded-xl py-2.5 pr-4 pl-10 cursor-pointer focus:outline-none transition-all"
              >
                <option value="newest">جدیدترین‌ها</option>
                <option value="popular">محبوب‌ترین‌ها</option>
                <option value="bestseller">پرفروش‌ترین‌های ماه</option>
                <option value="price_asc">ارزان‌ترین</option>
                <option value="price_desc">گران‌ترین (لوکس‌ترین)</option>
              </select>
              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400 text-lg">
                expand_more
              </span>
            </div>

            {/* Mobile Filter Toggle */}
            <button
              onClick={() => setMobileFilterOpen(true)}
              className="lg:hidden flex items-center gap-1.5 bg-[#f4f3f8] dark:bg-[#23242a] text-gray-900 dark:text-white text-xs font-semibold px-4 py-2.5 rounded-xl hover:bg-gray-200 transition-colors"
            >
              <span className="material-symbols-outlined text-base">tune</span>
              <span>فیلترها ({activeFiltersCount})</span>
            </button>
          </div>
        </div>

        {/* Active Filters Row */}
        {activeFiltersCount > 0 && (
          <div className="flex items-center gap-2 flex-wrap mb-6 text-xs text-gray-600 dark:text-gray-300">
            <span className="text-gray-400 font-medium">فیلترهای فعال:</span>

            {filters.categories.map(catId => {
              const cat = CATEGORIES_META.find(c => c.id === catId);
              return (
                <span
                  key={catId}
                  className="inline-flex items-center gap-1 bg-[#eeedf3] dark:bg-[#25262c] text-gray-800 dark:text-gray-200 px-3 py-1 rounded-full text-xs font-medium"
                >
                  <span>{cat?.name || catId}</span>
                  <button
                    onClick={() => handleCategoryToggle(catId)}
                    className="hover:text-red-500 transition-colors"
                  >
                    <span className="material-symbols-outlined text-xs">close</span>
                  </button>
                </span>
              );
            })}

            {filters.brands.map(brand => (
              <span
                key={brand}
                className="inline-flex items-center gap-1 bg-[#eeedf3] dark:bg-[#25262c] text-gray-800 dark:text-gray-200 px-3 py-1 rounded-full text-xs font-medium"
              >
                <span>برند: {brand}</span>
                <button
                  onClick={() => handleBrandToggle(brand)}
                  className="hover:text-red-500 transition-colors"
                >
                  <span className="material-symbols-outlined text-xs">close</span>
                </button>
              </span>
            ))}

            {filters.onlyInStock && (
              <span className="inline-flex items-center gap-1 bg-[#eeedf3] dark:bg-[#25262c] text-gray-800 dark:text-gray-200 px-3 py-1 rounded-full text-xs font-medium">
                <span>فقط کالاهای موجود</span>
                <button
                  onClick={() => setFilters(prev => ({ ...prev, onlyInStock: false }))}
                  className="hover:text-red-500 transition-colors"
                >
                  <span className="material-symbols-outlined text-xs">close</span>
                </button>
              </span>
            )}

            <button
              onClick={resetFilters}
              className="text-[#0071e3] dark:text-[#abc7ff] font-semibold hover:underline px-2"
            >
              پاک کردن همه
            </button>
          </div>
        )}

        {/* Layout Grid: 3-col Sidebar (Desktop) + 9-col Products */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Desktop Filter Sidebar */}
          <aside className="lg:col-span-3 space-y-6 hidden lg:block sticky top-24">
            <div className="bg-white dark:bg-[#1a1b1f] rounded-3xl p-6 shadow-xs border border-black/[0.03] dark:border-white/[0.05] space-y-6">
              {/* Categories */}
              <div>
                <div className="flex items-center justify-between pb-3 mb-2 border-b border-gray-100 dark:border-gray-800">
                  <h3 className="font-bold text-sm text-gray-900 dark:text-white">دسته‌بندی‌ها</h3>
                  <span className="text-[11px] text-gray-400">انتخاب چندگانه</span>
                </div>
                <div className="space-y-1.5">
                  {CATEGORIES_META.slice(0, 6).map(cat => (
                    <label
                      key={cat.id}
                      className="flex items-center justify-between group cursor-pointer py-1 text-xs"
                    >
                      <span className="flex items-center gap-2.5 text-gray-700 dark:text-gray-300 group-hover:text-[#0071e3] transition-colors">
                        <input
                          type="checkbox"
                          checked={filters.categories.includes(cat.id)}
                          onChange={() => handleCategoryToggle(cat.id)}
                          className="w-4 h-4 rounded text-[#0071e3] accent-[#0071e3] cursor-pointer"
                        />
                        <span>{cat.name}</span>
                      </span>
                      <span className="text-[11px] text-gray-400 group-hover:text-gray-600">
                        {toPersianDigits(cat.count)}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Price Range Slider */}
              <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-bold text-sm text-gray-900 dark:text-white">محدوده قیمت</h3>
                  <span className="text-xs text-[#0071e3] font-medium">تومان</span>
                </div>
                <div className="space-y-4">
                  <input
                    type="range"
                    min="850000"
                    max="18500000"
                    step="500000"
                    value={filters.priceRange[1]}
                    onChange={e =>
                      setFilters(prev => ({
                        ...prev,
                        priceRange: [prev.priceRange[0], parseInt(e.target.value)],
                      }))
                    }
                    className="w-full h-1.5 bg-gray-200 dark:bg-gray-700 rounded-lg appearance-none cursor-pointer accent-[#0071e3]"
                  />
                  <div className="flex items-center justify-between gap-2 text-xs text-gray-600 dark:text-gray-300 font-mono">
                    <div className="bg-[#f4f3f8] dark:bg-[#23242a] px-3 py-1.5 rounded-xl flex-1 text-center">
                      <span className="text-[10px] text-gray-400 block font-sans">از</span>
                      {formatPersianPrice(filters.priceRange[0])}
                    </div>
                    <span className="text-gray-400">-</span>
                    <div className="bg-[#f4f3f8] dark:bg-[#23242a] px-3 py-1.5 rounded-xl flex-1 text-center font-bold text-[#0071e3] dark:text-[#abc7ff]">
                      <span className="text-[10px] text-gray-400 block font-sans">تا</span>
                      {formatPersianPrice(filters.priceRange[1])}
                    </div>
                  </div>
                </div>
              </div>

              {/* Brands */}
              <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                <div className="flex items-center justify-between pb-3 mb-2">
                  <h3 className="font-bold text-sm text-gray-900 dark:text-white">برندهای تجاری</h3>
                </div>
                <div className="space-y-2">
                  {BRANDS.map(brand => (
                    <label
                      key={brand.id}
                      className="flex items-center justify-between group cursor-pointer py-0.5 text-xs"
                    >
                      <span className="flex items-center gap-2.5 text-gray-700 dark:text-gray-300 group-hover:text-[#0071e3] transition-colors">
                        <input
                          type="checkbox"
                          checked={filters.brands.includes(brand.name)}
                          onChange={() => handleBrandToggle(brand.name)}
                          className="w-4 h-4 rounded text-[#0071e3] accent-[#0071e3] cursor-pointer"
                        />
                        <span>{brand.name}</span>
                      </span>
                      {brand.isExclusive ? (
                        <span className="bg-[#0071e3]/10 dark:bg-[#0071e3]/20 text-[#0071e3] dark:text-[#abc7ff] text-[10px] font-bold px-2 py-0.5 rounded-full">
                          اختصاصی
                        </span>
                      ) : (
                        <span className="text-[11px] text-gray-400">{toPersianDigits(brand.count)}</span>
                      )}
                    </label>
                  ))}
                </div>
              </div>

              {/* Color Swatches */}
              <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
                <div className="flex items-center justify-between pb-2 mb-2">
                  <h3 className="font-bold text-sm text-gray-900 dark:text-white">پالت رنگ و متریال</h3>
                </div>
                <div className="flex items-center gap-2.5 flex-wrap">
                  {COLOR_PALETTE.map(c => {
                    const isSelected = filters.colors.includes(c.hex);
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() =>
                          setFilters(prev => ({
                            ...prev,
                            colors: isSelected ? prev.colors.filter(col => col !== c.hex) : [...prev.colors, c.hex],
                          }))
                        }
                        title={c.name}
                        className={`w-8 h-8 rounded-full shadow-xs flex items-center justify-center transition-all ${
                          isSelected ? 'ring-2 ring-[#0071e3] ring-offset-2 scale-110' : 'hover:scale-105'
                        }`}
                        style={{ backgroundColor: c.hex }}
                      >
                        {isSelected && (
                          <span className="material-symbols-outlined text-white text-xs font-bold">check</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Toggles */}
              <div className="pt-2 border-t border-gray-100 dark:border-gray-800 space-y-3">
                <label className="flex items-center justify-between cursor-pointer text-xs">
                  <span className="text-gray-700 dark:text-gray-300 font-medium">فقط کالاهای موجود</span>
                  <input
                    type="checkbox"
                    checked={filters.onlyInStock}
                    onChange={e => setFilters(prev => ({ ...prev, onlyInStock: e.target.checked }))}
                    className="w-4 h-4 rounded text-[#0071e3] accent-[#0071e3] cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer text-xs">
                  <span className="text-gray-700 dark:text-gray-300 font-medium">ارسال اکسپرس فوری</span>
                  <input
                    type="checkbox"
                    checked={filters.onlyExpress}
                    onChange={e => setFilters(prev => ({ ...prev, onlyExpress: e.target.checked }))}
                    className="w-4 h-4 rounded text-[#0071e3] accent-[#0071e3] cursor-pointer"
                  />
                </label>

                <label className="flex items-center justify-between cursor-pointer text-xs">
                  <span className="text-gray-700 dark:text-gray-300 font-medium">دارای تخفیف ویژه</span>
                  <input
                    type="checkbox"
                    checked={filters.onlyDiscount}
                    onChange={e => setFilters(prev => ({ ...prev, onlyDiscount: e.target.checked }))}
                    className="w-4 h-4 rounded text-[#0071e3] accent-[#0071e3] cursor-pointer"
                  />
                </label>
              </div>

              {/* Reset action */}
              <div className="pt-2 space-y-2">
                <button
                  onClick={resetFilters}
                  className="w-full bg-[#f4f3f8] dark:bg-[#23242a] text-gray-700 dark:text-gray-300 text-xs font-semibold py-2.5 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                >
                  تنظیم مجدد فیلترها
                </button>
              </div>
            </div>

            {/* Sidebar Promo Card */}
            <div className="rounded-3xl p-6 bg-[#f0eff5] dark:bg-[#1a1b1f] border border-black/[0.02] dark:border-white/[0.04] space-y-2 relative overflow-hidden">
              <span className="text-[#0071e3] dark:text-[#abc7ff] text-[11px] font-bold">پشتیبانی مهندسی ۲۴/۷</span>
              <h4 className="font-bold text-sm text-gray-900 dark:text-white">نیاز به راهنمایی فنی دارید؟</h4>
              <p className="text-xs text-gray-500 dark:text-gray-400 leading-relaxed">
                کارشناسان سخت‌افزار تکنونت استور سازگاری تجهیزات شارژ و مگ‌سیف دستگاه شما را دقیق بررسی می‌کنند.
              </p>
              <button
                onClick={() => setActivePage('support')}
                className="inline-flex items-center gap-1 text-[#0071e3] dark:text-[#abc7ff] text-xs font-bold pt-2 hover:underline cursor-pointer"
              >
                <span>گفتگو با مشاور تخصصی</span>
                <span className="material-symbols-outlined text-xs">arrow_back</span>
              </button>
            </div>
          </aside>

          {/* Main Products Grid Column */}
          <main className="lg:col-span-9 flex flex-col">
            {currentProducts.length === 0 ? (
              <div className="py-20 text-center bg-white dark:bg-[#1a1b1f] rounded-3xl p-8 border border-gray-100 dark:border-gray-800">
                <span className="material-symbols-outlined text-5xl text-gray-300 dark:text-gray-600 mb-4 block">
                  filter_alt_off
                </span>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                  هیچ محصولی با فیلترهای انتخابی یافت نشد
                </h3>
                <p className="text-xs text-gray-500 dark:text-gray-400 mb-6">
                  لطفاً فیلترها را ریست کنید یا کلیدواژه دیگری را امتحان فرمایید.
                </p>
                <button
                  onClick={resetFilters}
                  className="px-6 py-2.5 bg-[#0071e3] text-white rounded-full text-xs font-bold"
                >
                  پاک کردن همه فیلترها
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
                {currentProducts.map(product => {
                  const favorite = isFavorite(product.id);
                  return (
                    <article
                      key={product.id}
                      className="group bg-white dark:bg-[#1a1b1f] rounded-3xl p-4 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between border border-black/[0.03] dark:border-white/[0.04]"
                    >
                      <div className="space-y-4">
                        {/* Image stage with dual hover flip */}
                        <div
                          onClick={() => openProductDetail(product.id)}
                          className="relative w-full aspect-square rounded-2xl bg-[#faf8fe] dark:bg-[#22242a] overflow-hidden flex items-center justify-center p-4 cursor-pointer"
                        >
                          {/* Badges */}
                          <div className="absolute top-3 right-3 z-20 flex flex-col gap-1 items-start">
                            {product.badge && (
                              <span
                                className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full shadow-xs ${
                                  product.badgeType === 'discount'
                                    ? 'bg-rose-500 text-white'
                                    : 'bg-[#0071e3] text-white'
                                }`}
                              >
                                {product.badge}
                              </span>
                            )}
                            {product.discountPercent && (
                              <span className="bg-rose-100 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 text-[10px] font-bold px-2 py-0.5 rounded-full">
                                {toPersianDigits(product.discountPercent)}٪ تخفیف
                              </span>
                            )}
                          </div>

                          {/* Wishlist Heart */}
                          <button
                            onClick={e => {
                              e.stopPropagation();
                              toggleFavorite(product.id);
                            }}
                            aria-label="افزودن به علاقه‌مندی‌ها"
                            className="absolute top-3 left-3 z-20 w-9 h-9 rounded-full bg-white/80 dark:bg-black/50 backdrop-blur-md flex items-center justify-center text-gray-500 dark:text-gray-300 hover:text-rose-500 transition-colors shadow-xs"
                          >
                            <span
                              className={`material-symbols-outlined text-lg ${
                                favorite ? 'filled text-rose-500' : ''
                              }`}
                            >
                              favorite
                            </span>
                          </button>

                          {/* Primary Image */}
                          <img
                            src={product.image}
                            alt={product.name}
                            className="absolute inset-0 w-full h-full object-contain p-4 group-hover:opacity-0 transition-opacity duration-300"
                          />

                          {/* Hover Flip Image */}
                          <img
                            src={product.hoverImage || product.image}
                            alt={product.name}
                            className="absolute inset-0 w-full h-full object-contain p-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300 scale-105"
                          />
                        </div>

                        {/* Product Info */}
                        <div className="space-y-1.5 text-right">
                          <div className="flex items-center justify-between text-xs text-gray-400 font-semibold">
                            <span>{product.brand}</span>
                            <div className="flex items-center gap-1 text-gray-900 dark:text-white font-bold">
                              <span className="material-symbols-outlined text-amber-500 text-sm filled">
                                star
                              </span>
                              <span>{product.rating}</span>
                              <span className="text-gray-400 font-normal">
                                ({toPersianDigits(product.reviewCount)})
                              </span>
                            </div>
                          </div>

                          <h3
                            onClick={() => openProductDetail(product.id)}
                            className="font-bold text-sm text-gray-900 dark:text-white group-hover:text-[#0071e3] transition-colors line-clamp-1 cursor-pointer"
                          >
                            {product.name}
                          </h3>

                          <p className="text-xs text-gray-500 dark:text-gray-400 line-clamp-2 leading-relaxed">
                            {product.description}
                          </p>

                          {/* Color Options */}
                          <div className="flex items-center gap-1.5 pt-1">
                            {product.colors.map((c, i) => (
                              <span
                                key={c.id}
                                className={`w-3.5 h-3.5 rounded-full ${
                                  i === 0 ? 'ring-1 ring-[#0071e3] ring-offset-1' : ''
                                }`}
                                style={{ backgroundColor: c.hex }}
                                title={c.name}
                              />
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Price & Cart Button */}
                      <div className="pt-4 mt-4 border-t border-gray-100 dark:border-gray-800 flex items-center justify-between">
                        <div className="space-y-0.5 text-right">
                          {product.originalPrice && (
                            <div className="text-gray-400 line-through text-[11px]">
                              {formatPersianPrice(product.originalPrice)}
                            </div>
                          )}
                          <div className="text-sm font-bold text-gray-900 dark:text-white">
                            {formatPersianPrice(product.price)}{' '}
                            <span className="text-[11px] font-normal text-gray-500">تومان</span>
                          </div>
                        </div>

                        <button
                          onClick={() => addToCart(product)}
                          className="w-10 h-10 rounded-full bg-[#0071e3] text-white flex items-center justify-center hover:bg-[#005cbb] transition-all active:scale-95 shadow-sm"
                          title="افزودن به سبد خرید"
                        >
                          <span className="material-symbols-outlined text-lg">add_shopping_cart</span>
                        </button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}

            {/* Pagination */}
            {filteredProducts.length > pageSize && (
              <nav
                aria-label="صفحات محصولات"
                className="mt-12 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4"
              >
                <div className="text-xs text-gray-500 dark:text-gray-400">
                  نمایش{' '}
                  <span className="text-gray-900 dark:text-white font-bold">
                    {toPersianDigits((currentPage - 1) * pageSize + 1)} تا{' '}
                    {toPersianDigits(Math.min(currentPage * pageSize, filteredProducts.length))}
                  </span>{' '}
                  از{' '}
                  <span className="text-gray-900 dark:text-white font-bold">
                    {toPersianDigits(filteredProducts.length)}
                  </span>{' '}
                  کالای موجود
                </div>

                <div className="flex items-center gap-1.5 bg-white dark:bg-[#1a1b1f] p-1.5 rounded-full shadow-xs border border-gray-100 dark:border-gray-800">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-900 dark:hover:text-white disabled:opacity-30 disabled:pointer-events-none"
                    title="صفحه قبلی"
                  >
                    <span className="material-symbols-outlined text-base">chevron_right</span>
                  </button>

                  {Array.from({ length: totalPages }).map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentPage(idx + 1)}
                      className={`w-8 h-8 rounded-full text-xs font-semibold flex items-center justify-center transition-colors ${
                        currentPage === idx + 1
                          ? 'bg-[#0071e3] text-white shadow-xs'
                          : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800'
                      }`}
                    >
                      {toPersianDigits(idx + 1)}
                    </button>
                  ))}

                  <button
                    disabled={currentPage === totalPages}
                    onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                    className="w-8 h-8 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-900 dark:hover:text-white disabled:opacity-30 disabled:pointer-events-none"
                    title="صفحه بعدی"
                  >
                    <span className="material-symbols-outlined text-base">chevron_left</span>
                  </button>
                </div>
              </nav>
            )}
          </main>
        </div>
      </section>

      {/* Mobile Filters Slide-over / Modal */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex justify-end">
          <div className="w-full max-w-xs bg-white dark:bg-[#1a1b1f] h-full p-6 overflow-y-auto space-y-6 shadow-2xl animate-in slide-in-from-left duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100 dark:border-gray-800">
              <h3 className="font-bold text-base text-gray-900 dark:text-white">فیلترهای کاتالوگ</h3>
              <button
                onClick={() => setMobileFilterOpen(false)}
                className="w-8 h-8 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center"
              >
                <span className="material-symbols-outlined text-lg">close</span>
              </button>
            </div>

            {/* Categories */}
            <div>
              <h4 className="font-bold text-xs text-gray-900 dark:text-white mb-2">دسته‌بندی‌ها</h4>
              <div className="space-y-1 text-xs">
                {CATEGORIES_META.map(cat => (
                  <label key={cat.id} className="flex items-center gap-2 py-1">
                    <input
                      type="checkbox"
                      checked={filters.categories.includes(cat.id)}
                      onChange={() => handleCategoryToggle(cat.id)}
                      className="w-4 h-4 rounded text-[#0071e3] accent-[#0071e3]"
                    />
                    <span>{cat.name}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Brands */}
            <div className="pt-2 border-t border-gray-100 dark:border-gray-800">
              <h4 className="font-bold text-xs text-gray-900 dark:text-white mb-2">برندها</h4>
              <div className="space-y-1 text-xs">
                {BRANDS.map(brand => (
                  <label key={brand.id} className="flex items-center gap-2 py-1">
                    <input
                      type="checkbox"
                      checked={filters.brands.includes(brand.name)}
                      onChange={() => handleBrandToggle(brand.name)}
                      className="w-4 h-4 rounded text-[#0071e3] accent-[#0071e3]"
                    />
                    <span>{brand.name}</span>
                  </label>
                ))}
              </div>
            </div>

            <button
              onClick={() => setMobileFilterOpen(false)}
              className="w-full py-3 bg-[#0071e3] text-white rounded-full font-bold text-xs shadow-md"
            >
              مشاهده نتایج ({toPersianDigits(filteredProducts.length)})
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
