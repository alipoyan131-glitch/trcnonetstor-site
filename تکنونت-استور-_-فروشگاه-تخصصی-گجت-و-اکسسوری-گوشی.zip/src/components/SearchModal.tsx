import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { PRODUCTS } from '../data/products';
import { formatPersianPrice } from '../utils/formatters';

export const SearchModal: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, openProductDetail, setCategoryFilter } = useStore();
  const [query, setQuery] = useState('');

  const filteredProducts = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return PRODUCTS.filter(
      p =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.categoryLabel.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.shortSpecs.toLowerCase().includes(q)
    );
  }, [query]);

  if (!isSearchOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-start justify-center pt-16 sm:pt-24 px-4 animate-in fade-in duration-200">
      <div
        className="w-full max-w-2xl bg-white dark:bg-[#1a1b1f] rounded-3xl shadow-2xl overflow-hidden border border-gray-100 dark:border-gray-800 animate-in zoom-in-95 duration-200"
        onClick={e => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex items-center gap-3">
          <span className="material-symbols-outlined text-2xl text-gray-400">search</span>
          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="جستجوی عنوان محصول، فناوری (MagSafe، فیبر نوری، تیتانیوم...)"
            autoFocus
            className="flex-1 bg-transparent text-sm sm:text-base text-gray-900 dark:text-white placeholder:text-gray-400 focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 p-1"
            >
              <span className="material-symbols-outlined text-lg">close</span>
            </button>
          )}
          <button
            onClick={() => setIsSearchOpen(false)}
            className="text-xs bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 px-2.5 py-1 rounded-md text-gray-600 dark:text-gray-300 font-mono"
          >
            ESC
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-3 bg-[#faf8fe] dark:bg-[#16171b] border-b border-gray-100 dark:border-gray-800 flex items-center gap-2 overflow-x-auto text-xs">
          <span className="text-gray-400 whitespace-nowrap">پیشنهادهای داغ:</span>
          {['MagSafe', 'شارژر GaN', 'پاوربانک تیتانیوم', 'کولار 600D', 'تاندربولت 4', 'پایه ۳۶۰'].map(chip => (
            <button
              key={chip}
              onClick={() => setQuery(chip)}
              className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-[#0071e3] text-gray-700 dark:text-gray-300 px-2.5 py-1 rounded-full whitespace-nowrap transition-colors"
            >
              {chip}
            </button>
          ))}
        </div>

        {/* Search Results Area */}
        <div className="max-h-[60vh] overflow-y-auto p-4 space-y-2">
          {query.trim() === '' ? (
            <div className="py-8 text-center text-gray-400 text-sm">
              <span className="material-symbols-outlined text-4xl mb-2 block opacity-40">manage_search</span>
              عنوان محصول یا ویژگی فنی مورد نظر خود را تایپ فرمایید.
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="py-8 text-center text-gray-400 text-sm">
              <span className="material-symbols-outlined text-4xl mb-2 block opacity-40">sentiment_dissatisfied</span>
              هیچ کالایی متناسب با «{query}» یافت نشد.
            </div>
          ) : (
            filteredProducts.map(p => (
              <div
                key={p.id}
                onClick={() => {
                  openProductDetail(p.id);
                  setIsSearchOpen(false);
                }}
                className="flex items-center gap-3 p-2.5 rounded-2xl hover:bg-gray-50 dark:hover:bg-gray-800/60 transition-colors cursor-pointer group"
              >
                <div className="w-14 h-14 rounded-xl bg-gray-100 dark:bg-gray-800 p-1 flex-shrink-0 flex items-center justify-center">
                  <img src={p.image} alt={p.name} className="w-full h-full object-contain" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-gray-400">{p.brand}</span>
                    <span className="text-xs font-bold text-[#0071e3] dark:text-[#abc7ff]">
                      {formatPersianPrice(p.price)} تومان
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-gray-900 dark:text-white truncate group-hover:text-[#0071e3] transition-colors">
                    {p.name}
                  </h4>
                  <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{p.shortSpecs}</p>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-gray-50 dark:bg-[#16171b] border-t border-gray-100 dark:border-gray-800 text-center text-xs text-gray-400">
          کلید <kbd className="font-mono bg-white dark:bg-gray-800 px-1 py-0.5 rounded border border-gray-200 dark:border-gray-700">ESC</kbd> برای بستن سریع
        </div>
      </div>
    </div>
  );
};
