export type CategoryId = 
  | 'cases'
  | 'chargers'
  | 'cables'
  | 'powerbanks'
  | 'audio'
  | 'screen-protector'
  | 'car-mounts'
  | 'gaming'
  | 'wearable'
  | 'desktop';

export interface ProductColor {
  id: string;
  name: string;
  hex: string;
  gradient?: string;
}

export interface CapacityOption {
  id: string;
  label: string;
  capacity: string;
  specs: string;
  note: string;
  priceDelta: number;
}

export interface ReviewItem {
  id: string;
  author: string;
  initials: string;
  avatarColor: string;
  rating: number;
  date: string;
  variantPurchased: string;
  comment: string;
  verified: boolean;
}

export interface Product {
  id: string;
  code: string;
  name: string;
  slug: string;
  brand: string;
  brandCategory?: string;
  category: CategoryId;
  categoryLabel: string;
  price: number;
  originalPrice?: number;
  discountPercent?: number;
  badge?: string;
  badgeType?: 'primary' | 'discount' | 'new' | 'warranty';
  rating: number;
  reviewCount: number;
  image: string;
  hoverImage: string;
  gallery: {
    thumbnail: string;
    caption: string;
    largeAlt: string;
  }[];
  description: string;
  shortSpecs: string;
  colors: ProductColor[];
  capacities?: CapacityOption[];
  inStock: boolean;
  isExpress: boolean;
  hasDiscount: boolean;
  warrantyMonths: number;
  warrantyType: string;
  material: string;
  specs: {
    [key: string]: string;
  };
  boxContents: string[];
  reviews: ReviewItem[];
}

export interface CartItem {
  id: string;
  product: Product;
  quantity: number;
  selectedColor: ProductColor;
  selectedCapacity?: CapacityOption;
  unitPrice: number;
}

export interface FilterState {
  searchQuery: string;
  categories: CategoryId[];
  brands: string[];
  priceRange: [number, number];
  colors: string[];
  onlyInStock: boolean;
  onlyExpress: boolean;
  onlyDiscount: boolean;
  sortBy: 'newest' | 'popular' | 'bestseller' | 'price_asc' | 'price_desc';
}

export type ActivePage = 
  | 'home'
  | 'store'
  | 'product-detail'
  | 'cart'
  | 'categories'
  | 'favorites'
  | 'support';
