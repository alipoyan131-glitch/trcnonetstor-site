import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, ActivePage, FilterState, CategoryId, ProductColor, CapacityOption } from '../types';
import { PRODUCTS } from '../data/products';

interface StoreContextType {
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  selectedProductId: string;
  setSelectedProductId: (id: string) => void;
  openProductDetail: (id: string) => void;
  
  // Cart
  cart: CartItem[];
  addToCart: (product: Product, selectedColor?: ProductColor, selectedCapacity?: CapacityOption, quantity?: number) => void;
  updateCartQuantity: (itemId: string, delta: number) => void;
  removeFromCart: (itemId: string) => void;
  savedForLater: CartItem[];
  saveForLater: (itemId: string) => void;
  moveToCartFromSaved: (itemId: string) => void;
  cartTotalCount: number;
  cartSubtotal: number;
  cartDiscount: number;
  voucherDiscount: number;
  appliedCoupon: string | null;
  applyCouponCode: (code: string) => { success: boolean; message: string };
  clearCart: () => void;

  // Favorites / Wishlist
  favorites: string[];
  toggleFavorite: (productId: string) => void;
  isFavorite: (productId: string) => boolean;

  // Filter state for Store Catalog
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  setCategoryFilter: (catId: CategoryId) => void;

  // Search Modal
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;

  // Theme
  isDarkMode: boolean;
  toggleDarkMode: () => void;

  // Toast feedback
  toastMessage: string | null;
  showToast: (message: string) => void;

  // Checkout modal
  isQuickBuyOpen: boolean;
  setIsQuickBuyOpen: (open: boolean) => void;
  quickBuyProduct: Product | null;
  setQuickBuyProduct: (p: Product | null) => void;
}

const defaultFilters: FilterState = {
  searchQuery: '',
  categories: ['cases', 'chargers'],
  brands: ['TecnoNet Atelier'],
  priceRange: [850000, 12200000],
  colors: ['#1e1e24'],
  onlyInStock: true,
  onlyExpress: true,
  onlyDiscount: false,
  sortBy: 'newest',
};

const StoreContext = createContext<StoreContextType | undefined>(undefined);

export const StoreProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>('prod-magpro-titanium');

  // Initial cart populated as seen in mockup Image 7
  const [cart, setCart] = useState<CartItem[]>(() => {
    const item1 = PRODUCTS.find(p => p.id === 'prod-magstand-pro') || PRODUCTS[1];
    const item2 = PRODUCTS.find(p => p.id === 'prod-stealth-case') || PRODUCTS[7];
    const item3 = PRODUCTS.find(p => p.id === 'prod-thunderbolt-cable') || PRODUCTS[4];

    return [
      {
        id: 'cart-1',
        product: item1,
        quantity: 1,
        selectedColor: item1.colors[0],
        unitPrice: 4850000,
      },
      {
        id: 'cart-2',
        product: item2,
        quantity: 2,
        selectedColor: item2.colors[0],
        unitPrice: 1980000,
      },
      {
        id: 'cart-3',
        product: item3,
        quantity: 1,
        selectedColor: item3.colors[0],
        unitPrice: 1240000,
      },
    ];
  });

  const [savedForLater, setSavedForLater] = useState<CartItem[]>(() => {
    const hubProduct = PRODUCTS.find(p => p.id === 'prod-titanium-hub') || PRODUCTS[PRODUCTS.length - 1];
    return [
      {
        id: 'saved-hub',
        product: hubProduct,
        quantity: 1,
        selectedColor: hubProduct.colors[0],
        unitPrice: 2650000,
      },
    ];
  });

  const [favorites, setFavorites] = useState<string[]>(['prod-magpro-titanium', 'prod-magstand-pro']);
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [voucherDiscount, setVoucherDiscount] = useState(0);
  const [isQuickBuyOpen, setIsQuickBuyOpen] = useState(false);
  const [quickBuyProduct, setQuickBuyProduct] = useState<Product | null>(null);

  // Apply dark mode class to html element
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Global keyboard shortcut for ⌘K search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(prev => !prev);
      } else if (e.key === 'Escape') {
        setIsSearchOpen(false);
        setIsQuickBuyOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const toggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  const openProductDetail = (id: string) => {
    setSelectedProductId(id);
    setActivePage('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addToCart = (product: Product, selectedColor?: ProductColor, selectedCapacity?: CapacityOption, quantity = 1) => {
    const color = selectedColor || product.colors[0];
    const capacityPriceDelta = selectedCapacity?.priceDelta || 0;
    const finalUnitPrice = product.price + capacityPriceDelta;

    const existingIndex = cart.findIndex(
      item =>
        item.product.id === product.id &&
        item.selectedColor.id === color.id &&
        item.selectedCapacity?.id === selectedCapacity?.id
    );

    if (existingIndex > -1) {
      const updated = [...cart];
      updated[existingIndex].quantity += quantity;
      setCart(updated);
    } else {
      const newItem: CartItem = {
        id: `cart-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        product,
        quantity,
        selectedColor: color,
        selectedCapacity,
        unitPrice: finalUnitPrice,
      };
      setCart(prev => [newItem, ...prev]);
    }

    showToast(`«${product.name}» به سبد خرید اضافه شد.`);
  };

  const updateCartQuantity = (itemId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.id === itemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null);
    });
  };

  const removeFromCart = (itemId: string) => {
    setCart(prev => prev.filter(item => item.id !== itemId));
    showToast('کالا از سبد خرید حذف شد.');
  };

  const saveForLater = (itemId: string) => {
    const item = cart.find(i => i.id === itemId);
    if (item) {
      setCart(prev => prev.filter(i => i.id !== itemId));
      setSavedForLater(prev => [item, ...prev]);
      showToast('کالا به لیست ذخیره برای بعد منتقل شد.');
    }
  };

  const moveToCartFromSaved = (itemId: string) => {
    const item = savedForLater.find(i => i.id === itemId);
    if (item) {
      setSavedForLater(prev => prev.filter(i => i.id !== itemId));
      setCart(prev => [item, ...prev]);
      showToast('کالا مجدداً به سبد خرید بازگشت.');
    }
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleFavorite = (productId: string) => {
    setFavorites(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('از لیست علاقه‌مندی‌ها حذف شد.');
        return prev.filter(id => id !== productId);
      } else {
        showToast('به لیست علاقه‌مندی‌ها اضافه شد.');
        return [...prev, productId];
      }
    });
  };

  const isFavorite = (productId: string) => favorites.includes(productId);

  const resetFilters = () => {
    setFilters({
      searchQuery: '',
      categories: [],
      brands: [],
      priceRange: [850000, 18500000],
      colors: [],
      onlyInStock: false,
      onlyExpress: false,
      onlyDiscount: false,
      sortBy: 'newest',
    });
  };

  const setCategoryFilter = (catId: CategoryId) => {
    setFilters(prev => ({
      ...prev,
      categories: [catId],
    }));
    setActivePage('store');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const applyCouponCode = (code: string) => {
    const clean = code.trim().toUpperCase();
    if (clean === 'TECNO500') {
      setAppliedCoupon('TECNO500');
      setVoucherDiscount(500000);
      showToast('کوپن تخفیف ۵۰۰,۰۰۰ تومانی با موفقیت لحاظ شد!');
      return { success: true, message: 'کوپن ۵۰۰,۰۰۰ تومانی با موفقیت اعمال گردید.' };
    } else if (clean === 'VIP2025') {
      setAppliedCoupon('VIP2025');
      setVoucherDiscount(750000);
      showToast('کوپن تخفیف طلایی ۷۵۰,۰۰۰ تومانی لحاظ شد!');
      return { success: true, message: 'کوپن تخفیف VIP اعضا اعمال گردید.' };
    } else {
      return { success: false, message: 'کد تخفیف وارد شده نامعتبر یا منقضی است.' };
    }
  };

  const cartTotalCount = cart.reduce((acc, curr) => acc + curr.quantity, 0);
  const cartSubtotal = cart.reduce((acc, curr) => acc + curr.unitPrice * curr.quantity, 0);
  const cartDiscount = cart.length > 0 ? 350000 : 0; // Special promotional discount

  return (
    <StoreContext.Provider
      value={{
        activePage,
        setActivePage: (p) => {
          setActivePage(p);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        },
        selectedProductId,
        setSelectedProductId,
        openProductDetail,

        cart,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        savedForLater,
        saveForLater,
        moveToCartFromSaved,
        cartTotalCount,
        cartSubtotal,
        cartDiscount,
        voucherDiscount,
        appliedCoupon,
        applyCouponCode,
        clearCart,

        favorites,
        toggleFavorite,
        isFavorite,

        filters,
        setFilters,
        resetFilters,
        setCategoryFilter,

        isSearchOpen,
        setIsSearchOpen,

        isDarkMode,
        toggleDarkMode,

        toastMessage,
        showToast,

        isQuickBuyOpen,
        setIsQuickBuyOpen,
        quickBuyProduct,
        setQuickBuyProduct,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
};
